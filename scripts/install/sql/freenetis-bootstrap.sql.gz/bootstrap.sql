-- FreenetIS Laravel — bootstrap schema + system lookup data
-- Generováno z dev DB. Žádná uživatelská data (members/accounts/transfers/etc.).
-- Po importu spusť: php artisan freenetis:install

/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.3-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: freenetis
-- ------------------------------------------------------
-- Server version	11.8.3-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `account_attributes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_attributes` (
  `id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(230) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT 'aktivní, pasivní, daňový, nedaňový',
  `kind` tinyint(4) DEFAULT NULL COMMENT 'rozvahový, výsledovkový, závěrkový, podrozvahový',
  `activity` tinyint(4) DEFAULT NULL COMMENT 'hlavní/hospodářská činnost',
  `track_balance` tinyint(4) DEFAULT NULL COMMENT 'true, false',
  `line` tinyint(4) DEFAULT NULL COMMENT 'řádek plné výsledovky',
  `line_short` tinyint(4) DEFAULT NULL COMMENT 'řádek zkrácené výsledovky',
  `line_credits` tinyint(4) DEFAULT NULL COMMENT 'řádek pasiv',
  `line_credits_short` tinyint(4) DEFAULT NULL COMMENT 'řádek zkrácených pasiv ',
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `account_attribute_id` int(11) NOT NULL,
  `balance` double DEFAULT 0 COMMENT 'Account balance, value is updated with respect to transfers of account',
  `comment` varchar(254) DEFAULT NULL,
  `comments_thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_owned_by` (`member_id`),
  KEY `comments_thread_id` (`comments_thread_id`),
  KEY `account_attribute_id` (`account_attribute_id`),
  KEY `balance` (`balance`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `accounts_ibfk_2` FOREIGN KEY (`account_attribute_id`) REFERENCES `account_attributes` (`id`),
  CONSTRAINT `accounts_ibfk_3` FOREIGN KEY (`comments_thread_id`) REFERENCES `comments_threads` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10114 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounts_bank_accounts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_bank_accounts` (
  `account_id` int(11) NOT NULL,
  `bank_account_id` int(11) NOT NULL,
  PRIMARY KEY (`account_id`,`bank_account_id`),
  KEY `bank_account_id` (`bank_account_id`),
  CONSTRAINT `accounts_bank_accounts_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accounts_bank_accounts_ibfk_2` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `acl`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `acl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aco`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aco` (
  `id` int(11) NOT NULL DEFAULT 0,
  `value` varchar(240) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_value_value_aco` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aco_map`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aco_map` (
  `acl_id` int(11) NOT NULL DEFAULT 0,
  `value` varchar(230) NOT NULL,
  PRIMARY KEY (`acl_id`,`value`),
  CONSTRAINT `aco_map_ibfk_1` FOREIGN KEY (`acl_id`) REFERENCES `acl` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address_points`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `country_id` smallint(6) NOT NULL,
  `town_id` int(11) NOT NULL,
  `street_id` int(11) DEFAULT NULL,
  `street_number` varchar(50) DEFAULT NULL,
  `gps` point DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `street_id` (`street_id`),
  KEY `town_id` (`town_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `address_points_ibfk_1` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `address_points_ibfk_2` FOREIGN KEY (`town_id`) REFERENCES `towns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `address_points_ibfk_3` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11810 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `allowed_subnets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `allowed_subnets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `subnet_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `allowed_subnets_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `allowed_subnets_ibfk_2` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8918 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `allowed_subnets_counts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `allowed_subnets_counts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `allowed_subnets_counts_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4408 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `approval_template_items`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_template_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approval_template_id` int(11) DEFAULT NULL,
  `approval_type_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `approval_template_id` (`approval_template_id`),
  KEY `approval_type_id` (`approval_type_id`),
  CONSTRAINT `approval_template_items_ibfk_1` FOREIGN KEY (`approval_template_id`) REFERENCES `approval_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `approval_template_items_ibfk_2` FOREIGN KEY (`approval_type_id`) REFERENCES `approval_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `approval_templates`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `comment` mediumtext NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `approval_types`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `comment` mediumtext NOT NULL,
  `type` int(11) NOT NULL,
  `majority_percent` int(11) NOT NULL,
  `aro_group_id` int(11) NOT NULL,
  `interval` datetime NOT NULL,
  `default_vote` tinyint(1) DEFAULT NULL,
  `min_suggest_amount` int(11) NOT NULL,
  `one_vote` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'Only one vote (approve/reject) required to end voting.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aro_groups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aro_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `lft` int(11) NOT NULL DEFAULT 0,
  `rgt` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`value`),
  UNIQUE KEY `value_aro_groups` (`value`),
  KEY `parent_id_aro_groups` (`parent_id`),
  KEY `lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aro_groups_map`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aro_groups_map` (
  `acl_id` int(11) NOT NULL DEFAULT 0,
  `group_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`acl_id`,`group_id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `aro_groups_map_ibfk_1` FOREIGN KEY (`acl_id`) REFERENCES `acl` (`id`) ON DELETE CASCADE,
  CONSTRAINT `aro_groups_map_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `aro_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `axo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `axo` (
  `id` int(11) NOT NULL DEFAULT 0,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_value_value_axo` (`section_value`,`value`),
  KEY `value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `axo_map`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `axo_map` (
  `acl_id` int(11) NOT NULL DEFAULT 0,
  `section_value` varchar(230) NOT NULL DEFAULT '0',
  `value` varchar(230) NOT NULL,
  PRIMARY KEY (`acl_id`,`section_value`,`value`),
  CONSTRAINT `axo_map_ibfk_1` FOREIGN KEY (`acl_id`) REFERENCES `acl` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `axo_sections`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `axo_sections` (
  `id` int(11) NOT NULL DEFAULT 0,
  `value` varchar(230) NOT NULL,
  `name` varchar(230) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value_axo_sections` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_accounts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(254) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `account_nr` varchar(254) DEFAULT NULL,
  `bank_nr` varchar(20) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 0,
  `settings` text DEFAULT NULL COMMENT 'JSON',
  `IBAN` varchar(254) DEFAULT NULL,
  `SWIFT` varchar(254) DEFAULT NULL,
  `payment_purpose` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 - clenstvi, 1 - zakaznici',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `bank_accounts_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10832 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_accounts_automatical_downloads`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_accounts_automatical_downloads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_account_id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `email_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `sms_enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `bank_account_id_fk` (`bank_account_id`),
  CONSTRAINT `bank_accounts_automatical_downloads_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_statements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_account_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `statement_number` int(11) DEFAULT NULL,
  `type` varchar(40) DEFAULT NULL,
  `from` datetime DEFAULT NULL,
  `to` datetime DEFAULT NULL,
  `opening_balance` double DEFAULT NULL,
  `closing_balance` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_account_id` (`bank_account_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `bank_statements_ibfk_1` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`),
  CONSTRAINT `bank_statements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16894 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_transfers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `origin_id` int(11) DEFAULT NULL COMMENT 'id of the origin bank account in bank_accounts table',
  `destination_id` int(11) DEFAULT NULL COMMENT 'id of the destination bank account in bank_accounts table',
  `transfer_id` int(11) DEFAULT NULL,
  `bank_statement_id` int(11) DEFAULT NULL,
  `transaction_code` bigint(20) DEFAULT NULL,
  `number` int(11) DEFAULT NULL COMMENT 'Line number or number of the bank listing item',
  `variable_symbol` bigint(20) DEFAULT NULL,
  `constant_symbol` bigint(20) DEFAULT NULL,
  `specific_symbol` bigint(20) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `origin_id` (`origin_id`),
  KEY `destination_id` (`destination_id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `number` (`number`,`variable_symbol`),
  KEY `bank_statement_id` (`bank_statement_id`),
  CONSTRAINT `bank_transfers_ibfk_1` FOREIGN KEY (`origin_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bank_transfers_ibfk_2` FOREIGN KEY (`destination_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bank_transfers_ibfk_3` FOREIGN KEY (`transfer_id`) REFERENCES `transfers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bank_transfers_ibfk_4` FOREIGN KEY (`bank_statement_id`) REFERENCES `bank_statements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=170641 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cash`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `transfer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `transfer_id` (`transfer_id`),
  CONSTRAINT `cash_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_ibfk_2` FOREIGN KEY (`transfer_id`) REFERENCES `transfers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='implements cash deposits and withdrawals ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clouds`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clouds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clouds_subnets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clouds_subnets` (
  `cloud_id` int(11) NOT NULL,
  `subnet_id` int(11) NOT NULL,
  PRIMARY KEY (`cloud_id`,`subnet_id`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `clouds_subnets_ibfk_1` FOREIGN KEY (`cloud_id`) REFERENCES `clouds` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clouds_subnets_ibfk_2` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Join table between subnets and clouds.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clouds_users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clouds_users` (
  `cloud_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`cloud_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `clouds_users_ibfk_1` FOREIGN KEY (`cloud_id`) REFERENCES `clouds` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clouds_users_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Join table between users and clouds.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `comments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_thread_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `comments_thread_id` (`comments_thread_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`comments_thread_id`) REFERENCES `comments_threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=276 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `comments_threads`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `connection_requests`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `connection_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL COMMENT 'Owner of the connection',
  `added_user_id` int(11) DEFAULT NULL COMMENT 'Who made request',
  `decided_user_id` int(11) DEFAULT NULL COMMENT 'User who approve/reject this connection request.',
  `state` int(11) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `decided_at` datetime DEFAULT NULL,
  `ip_address` varchar(39) NOT NULL,
  `subnet_id` int(11) NOT NULL,
  `mac_address` varchar(17) NOT NULL,
  `device_id` int(11) DEFAULT NULL COMMENT 'ID of the device that was created from this connection request or null.',
  `device_type_id` int(11) DEFAULT NULL,
  `device_template_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL COMMENT 'Comment of user who made request',
  `comments_thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id_fk` (`member_id`),
  KEY `subnet_id_fk` (`subnet_id`),
  KEY `device_type_id_fk` (`device_type_id`),
  KEY `device_template_id_fk` (`device_template_id`),
  KEY `comments_thread_id_fk` (`comments_thread_id`),
  KEY `decided_user_id_fk` (`decided_user_id`),
  KEY `device_id_fk` (`device_id`),
  KEY `added_user_id_fk` (`added_user_id`),
  CONSTRAINT `connection_requests_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `connection_requests_ibfk_3` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `connection_requests_ibfk_4` FOREIGN KEY (`device_type_id`) REFERENCES `enum_types` (`id`) ON DELETE SET NULL,
  CONSTRAINT `connection_requests_ibfk_5` FOREIGN KEY (`device_template_id`) REFERENCES `device_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `connection_requests_ibfk_6` FOREIGN KEY (`comments_thread_id`) REFERENCES `comments_threads` (`id`) ON DELETE SET NULL,
  CONSTRAINT `connection_requests_ibfk_7` FOREIGN KEY (`decided_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `connection_requests_ibfk_8` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `connection_requests_ibfk_9` FOREIGN KEY (`added_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4760 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `value` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=22114 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contacts_countries`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts_countries` (
  `contact_id` int(11) NOT NULL,
  `country_id` smallint(6) NOT NULL,
  PRIMARY KEY (`contact_id`,`country_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `contacts_countries_ibfk_1` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_countries_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_countries_ibfk_3` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_countries_ibfk_4` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Relation between phone number in contacts to countries.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `countries`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL COMMENT 'Country name in english',
  `country_iso` char(3) NOT NULL COMMENT 'ISO 3166-1 alpha-3',
  `country_code` varchar(4) NOT NULL COMMENT 'Telefone prefix of country',
  `enabled` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_active_links`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_active_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_pattern` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `show_in_user_grid` tinyint(4) NOT NULL,
  `show_in_grid` tinyint(4) NOT NULL,
  `as_form` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_active_links_map`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_active_links_map` (
  `device_active_link_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL,
  KEY `device_active_link_id` (`device_active_link_id`,`device_id`),
  CONSTRAINT `device_active_links_map_ibfk_1` FOREIGN KEY (`device_active_link_id`) REFERENCES `device_active_links` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_admins`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `device_id` (`device_id`),
  CONSTRAINT `device_admins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `device_admins_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_engineers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_engineers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `device_id` (`device_id`),
  CONSTRAINT `device_engineers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `device_engineers_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6271 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device_templates`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enum_type_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `values` text NOT NULL,
  `default` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `device_templates_category_id` (`enum_type_id`),
  CONSTRAINT `device_templates_ibfk_enum_type` FOREIGN KEY (`enum_type_id`) REFERENCES `enum_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `devices`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `address_point_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `trade_name` varchar(50) DEFAULT NULL,
  `operating_system` tinyint(4) DEFAULT NULL,
  `PPPoE_logging_in` tinyint(4) DEFAULT NULL,
  `login` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `access_time` datetime DEFAULT NULL,
  `price` double DEFAULT NULL,
  `payment_rate` double DEFAULT NULL,
  `buy_date` date DEFAULT NULL,
  `comment` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `address_point_id` (`address_point_id`),
  CONSTRAINT `devices_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `devices_ibfk_2` FOREIGN KEY (`address_point_id`) REFERENCES `address_points` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10435 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `email_queue_attachments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_queue_id` int(11) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mime` char(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email_queue_id` (`email_queue_id`),
  CONSTRAINT `email_queue_attachments_ibfk_1` FOREIGN KEY (`email_queue_id`) REFERENCES `email_queues` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4752 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `email_queues`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  `access_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `from` (`from`,`to`),
  KEY `idx_state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=416171 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `enum_type_names`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `enum_type_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `enum_types`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `enum_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `value` varchar(254) DEFAULT NULL,
  `read_only` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `enum_types_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `enum_type_names` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fees`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `readonly` tinyint(1) NOT NULL,
  `fee` double NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `type_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL COMMENT 'Optional name for fee, useable as tariff name in case of regular member fee',
  `special_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `fees_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `enum_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `filter_queries`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `values` text NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gpon_olts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gpon_olts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `snmp_user` varchar(100) NOT NULL DEFAULT 'admin',
  `snmp_auth_pass` varchar(100) NOT NULL DEFAULT '',
  `snmp_priv_pass` varchar(100) NOT NULL DEFAULT '',
  `snmp_auth_proto` varchar(10) NOT NULL DEFAULT 'SHA',
  `snmp_priv_proto` varchar(10) NOT NULL DEFAULT 'AES',
  `line_prof` varchar(100) NOT NULL DEFAULT 'line-profile_default_0',
  `service_prof` varchar(100) NOT NULL DEFAULT 'sfu-aio-dmc',
  `traffic_table` varchar(100) NOT NULL DEFAULT 'int',
  `gpon_port` varchar(20) NOT NULL DEFAULT '0/1/0',
  `base_vlan` int(11) DEFAULT NULL,
  `port_count` int(11) DEFAULT NULL,
  `geocode_city` varchar(100) DEFAULT NULL,
  `vlan_map` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`vlan_map`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gpon_olts_ip_unique` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `groups_aro_map`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT 0,
  `aro_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`group_id`,`aro_id`),
  KEY `aro_id` (`aro_id`),
  CONSTRAINT `groups_aro_map_ibfk_1` FOREIGN KEY (`aro_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `groups_aro_map_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `aro_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ifaces`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ifaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `link_id` int(11) DEFAULT NULL,
  `mac` varchar(20) DEFAULT NULL,
  `name` varchar(254) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `wireless_mode` int(11) DEFAULT NULL,
  `wireless_antenna` int(11) DEFAULT NULL,
  `port_mode` int(11) DEFAULT NULL,
  `comment` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_iface` (`device_id`),
  KEY `segment_iface` (`link_id`),
  KEY `type` (`type`),
  CONSTRAINT `ifaces_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ifaces_ibfk_2` FOREIGN KEY (`link_id`) REFERENCES `links` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24369 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ifaces_relationships`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ifaces_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_iface_id` int(11) NOT NULL,
  `iface_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_iface_id` (`iface_id`),
  KEY `iface_id` (`iface_id`),
  KEY `parent_iface_id_2` (`parent_iface_id`),
  CONSTRAINT `ifaces_relationships_ibfk_1` FOREIGN KEY (`parent_iface_id`) REFERENCES `ifaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ifaces_relationships_ibfk_2` FOREIGN KEY (`iface_id`) REFERENCES `ifaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1360 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ifaces_vlans`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ifaces_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iface_id` int(11) NOT NULL,
  `vlan_id` int(11) NOT NULL,
  `tagged` tinyint(1) DEFAULT NULL,
  `port_vlan` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iface_id` (`iface_id`),
  KEY `vlan_id` (`vlan_id`),
  CONSTRAINT `ifaces_vlans_ibfk_1` FOREIGN KEY (`iface_id`) REFERENCES `ifaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ifaces_vlans_ibfk_2` FOREIGN KEY (`vlan_id`) REFERENCES `vlans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29141 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invoice_items`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(100) NOT NULL,
  `quantity` double NOT NULL,
  `author_fee` double NOT NULL,
  `contractual_increase` double NOT NULL,
  `service` tinyint(1) NOT NULL,
  `price` double NOT NULL,
  `vat` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4129 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invoice_templates`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `invoices` varchar(255) DEFAULT NULL,
  `sup_company` text DEFAULT NULL,
  `sup_name` text DEFAULT NULL,
  `sup_street` varchar(255) DEFAULT NULL,
  `sup_street_number` varchar(255) DEFAULT NULL,
  `sup_town` varchar(255) DEFAULT NULL,
  `sup_zip_code` varchar(255) DEFAULT NULL,
  `sup_country` varchar(255) DEFAULT NULL,
  `sup_organization_identifier` varchar(255) DEFAULT NULL,
  `sup_vat_organization_identifier` varchar(255) DEFAULT NULL,
  `sup_phone_number` varchar(255) DEFAULT NULL,
  `sup_email` varchar(255) DEFAULT NULL,
  `cus_company` text DEFAULT NULL,
  `cus_name` text DEFAULT NULL,
  `cus_street` varchar(255) DEFAULT NULL,
  `cus_street_number` varchar(255) DEFAULT NULL,
  `cus_town` varchar(255) DEFAULT NULL,
  `cus_zip_code` varchar(255) DEFAULT NULL,
  `cus_country` varchar(255) DEFAULT NULL,
  `cus_organization_identifier` varchar(255) DEFAULT NULL,
  `cus_phone_number` varchar(255) DEFAULT NULL,
  `cus_email` varchar(255) DEFAULT NULL,
  `org_id` varchar(255) DEFAULT NULL,
  `invoice_nr` varchar(255) DEFAULT NULL,
  `invoice_type` varchar(255) DEFAULT NULL,
  `invoice_type_issued` varchar(255) DEFAULT NULL,
  `account_nr` text DEFAULT NULL,
  `var_sym` varchar(255) DEFAULT NULL,
  `con_sym` varchar(255) DEFAULT NULL,
  `date_inv` varchar(255) DEFAULT NULL,
  `date_due` varchar(255) DEFAULT NULL,
  `date_vat` varchar(255) DEFAULT NULL,
  `vat` varchar(255) DEFAULT NULL,
  `order_nr` varchar(255) DEFAULT NULL,
  `price` text DEFAULT NULL,
  `price_vat` text DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `items` varchar(255) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_code` varchar(255) DEFAULT NULL,
  `item_quantity` varchar(255) DEFAULT NULL,
  `item_price` varchar(255) DEFAULT NULL,
  `item_vat` varchar(255) DEFAULT NULL,
  `charset` varchar(100) DEFAULT NULL,
  `namespace` text DEFAULT NULL,
  `vat_variables` text DEFAULT NULL,
  `type` tinyint(1) NOT NULL,
  `begin_tag` varchar(100) DEFAULT NULL,
  `end_tag` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `invoices`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `partner_company` varchar(100) DEFAULT NULL,
  `partner_name` varchar(100) DEFAULT NULL,
  `partner_street` varchar(30) DEFAULT NULL,
  `partner_street_number` varchar(50) DEFAULT NULL,
  `partner_town` varchar(50) DEFAULT NULL,
  `partner_zip_code` varchar(10) DEFAULT NULL,
  `partner_country` varchar(100) DEFAULT NULL,
  `organization_identifier` varchar(20) DEFAULT NULL,
  `vat_organization_identifier` varchar(30) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `invoice_nr` double NOT NULL,
  `invoice_type` tinyint(1) NOT NULL,
  `account_nr` varchar(254) DEFAULT NULL,
  `var_sym` double NOT NULL,
  `con_sym` double DEFAULT NULL,
  `date_inv` date NOT NULL,
  `date_due` date NOT NULL,
  `date_vat` date NOT NULL,
  `vat` tinyint(1) NOT NULL,
  `order_nr` double DEFAULT NULL,
  `currency` varchar(3) NOT NULL,
  `note` varchar(240) DEFAULT NULL,
  `pdf_filename` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4073 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ip6_addresses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip6_addresses` (
  `iface_id` int(11) DEFAULT NULL,
  `subnet_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `dhcp` tinyint(4) DEFAULT NULL,
  `gateway` tinyint(4) DEFAULT NULL,
  `service` tinyint(4) NOT NULL DEFAULT 0,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `ip_addresses_key_iface_id` (`iface_id`),
  KEY `ip_addresses_key_subnet_id` (`subnet_id`),
  KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=5842 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ip_addresses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_addresses` (
  `iface_id` int(11) DEFAULT NULL,
  `subnet_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `dhcp` tinyint(4) DEFAULT NULL,
  `gateway` tinyint(4) DEFAULT NULL,
  `service` tinyint(4) NOT NULL DEFAULT 0,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `ip_addresses_key_iface_id` (`iface_id`),
  KEY `ip_addresses_key_subnet_id` (`subnet_id`),
  KEY `ip_address` (`ip_address`),
  CONSTRAINT `ip_addresses_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ip_addresses_ibfk_5` FOREIGN KEY (`iface_id`) REFERENCES `ifaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ip_addresses_ibfk_6` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39048 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ip_addresses_traffics`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_addresses_traffics` (
  `ip_address` varchar(15) NOT NULL,
  `upload` int(11) unsigned NOT NULL,
  `download` int(11) unsigned NOT NULL,
  `local_upload` int(11) NOT NULL,
  `local_download` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ip_address`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_reports`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `added_by_id` int(11) DEFAULT NULL,
  `transfer_id` int(11) DEFAULT NULL,
  `approval_template_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `type` char(7) DEFAULT NULL COMMENT 'If null then type is gouped report, else type is monthly report and should contains date string in form ''YYYY-mm''',
  `price_per_hour` double NOT NULL COMMENT 'Price per hour for each work in report.',
  `price_per_km` double NOT NULL COMMENT 'Price per kilometre for each work in report.',
  `concept` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Concept is displayed only to owner',
  `payment_type` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'Specified payment, 0 is credit payment, 1 is cash payment, see model for more details',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `approval_template_id` (`approval_template_id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `added_by_id` (`added_by_id`),
  CONSTRAINT `job_reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_reports_ibfk_2` FOREIGN KEY (`approval_template_id`) REFERENCES `approval_templates` (`id`),
  CONSTRAINT `job_reports_ibfk_4` FOREIGN KEY (`added_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `job_reports_ibfk_5` FOREIGN KEY (`transfer_id`) REFERENCES `transfers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_report_id` int(11) DEFAULT NULL COMMENT 'belongs to job report',
  `user_id` int(11) NOT NULL,
  `previous_rejected_work_id` int(11) DEFAULT NULL,
  `added_by_id` int(11) DEFAULT NULL,
  `approval_template_id` int(11) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `suggest_amount` int(11) NOT NULL COMMENT 'suggest amount by user',
  `date` date NOT NULL,
  `create_date` datetime NOT NULL COMMENT 'date of creation of work in IS',
  `hours` float DEFAULT NULL,
  `km` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `transfer_id` int(11) DEFAULT NULL,
  `comments_thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commited_by` (`user_id`),
  KEY `transfer_salary` (`transfer_id`),
  KEY `comments_thread_id` (`comments_thread_id`),
  KEY `job_report_id` (`job_report_id`),
  KEY `added_by_id` (`added_by_id`),
  KEY `approval_template_id` (`approval_template_id`),
  KEY `previous_rejected_work_id` (`previous_rejected_work_id`),
  CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`job_report_id`) REFERENCES `job_reports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jobs_ibfk_3` FOREIGN KEY (`added_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_4` FOREIGN KEY (`approval_template_id`) REFERENCES `approval_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_5` FOREIGN KEY (`transfer_id`) REFERENCES `transfers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_6` FOREIGN KEY (`comments_thread_id`) REFERENCES `comments_threads` (`id`) ON DELETE SET NULL,
  CONSTRAINT `jobs_ibfk_7` FOREIGN KEY (`previous_rejected_work_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `links`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `medium` int(11) NOT NULL,
  `bitrate` bigint(20) DEFAULT NULL,
  `duplex` tinyint(4) DEFAULT NULL,
  `wireless_ssid` varchar(255) DEFAULT NULL,
  `wireless_norm` int(11) DEFAULT NULL,
  `wireless_frequency` int(11) DEFAULT NULL,
  `wireless_channel` int(11) DEFAULT NULL,
  `wireless_channel_width` int(11) DEFAULT NULL,
  `wireless_polarization` int(11) DEFAULT NULL,
  `comment` varchar(254) DEFAULT NULL,
  `gps` linestring DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3831 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `local_subnets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_subnets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_address` varchar(15) DEFAULT NULL,
  `netmask` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `network_address_2` (`network_address`),
  KEY `network_address` (`network_address`),
  KEY `netmask` (`netmask`)
) ENGINE=InnoDB AUTO_INCREMENT=1591 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_queues`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_queues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL,
  `state` smallint(6) NOT NULL,
  `created_at` datetime NOT NULL,
  `closed_by_user_id` int(11) DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `description` text NOT NULL,
  `exception_backtrace` text DEFAULT NULL,
  `comments_thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `closed_by_user_id_fk` (`closed_by_user_id`),
  KEY `comments_thread_id_fk` (`comments_thread_id`),
  CONSTRAINT `log_queues_ibfk_1` FOREIGN KEY (`closed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `log_queues_ibfk_2` FOREIGN KEY (`comments_thread_id`) REFERENCES `comments_threads` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=98658 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `IP_address` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=98115 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) NOT NULL,
  `values` text DEFAULT NULL,
  `time` datetime NOT NULL,
  `action` tinyint(2) NOT NULL DEFAULT 1,
  `object_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1230719 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci
 PARTITION BY RANGE (to_days(`time`))
(PARTITION `p_first` VALUES LESS THAN (719528) ENGINE = InnoDB,
 PARTITION `p_2026_03_28` VALUES LESS THAN (740069) ENGINE = InnoDB,
 PARTITION `p_2026_03_29` VALUES LESS THAN (740070) ENGINE = InnoDB,
 PARTITION `p_2026_03_30` VALUES LESS THAN (740071) ENGINE = InnoDB,
 PARTITION `p_2026_03_31` VALUES LESS THAN (740072) ENGINE = InnoDB,
 PARTITION `p_2026_04_01` VALUES LESS THAN (740073) ENGINE = InnoDB,
 PARTITION `p_2026_04_02` VALUES LESS THAN (740074) ENGINE = InnoDB,
 PARTITION `p_2026_04_03` VALUES LESS THAN (740075) ENGINE = InnoDB,
 PARTITION `p_2026_04_04` VALUES LESS THAN (740076) ENGINE = InnoDB,
 PARTITION `p_2026_04_05` VALUES LESS THAN (740077) ENGINE = InnoDB,
 PARTITION `p_2026_04_06` VALUES LESS THAN (740078) ENGINE = InnoDB,
 PARTITION `p_2026_04_07` VALUES LESS THAN (740079) ENGINE = InnoDB,
 PARTITION `p_2026_04_08` VALUES LESS THAN (740080) ENGINE = InnoDB,
 PARTITION `p_2026_04_09` VALUES LESS THAN (740081) ENGINE = InnoDB,
 PARTITION `p_2026_04_10` VALUES LESS THAN (740082) ENGINE = InnoDB,
 PARTITION `p_2026_04_11` VALUES LESS THAN (740083) ENGINE = InnoDB,
 PARTITION `p_2026_04_12` VALUES LESS THAN (740084) ENGINE = InnoDB,
 PARTITION `p_2026_04_13` VALUES LESS THAN (740085) ENGINE = InnoDB,
 PARTITION `p_2026_04_14` VALUES LESS THAN (740086) ENGINE = InnoDB,
 PARTITION `p_2026_04_15` VALUES LESS THAN (740087) ENGINE = InnoDB,
 PARTITION `p_2026_04_16` VALUES LESS THAN (740088) ENGINE = InnoDB,
 PARTITION `p_2026_04_17` VALUES LESS THAN (740089) ENGINE = InnoDB,
 PARTITION `p_2026_04_18` VALUES LESS THAN (740090) ENGINE = InnoDB,
 PARTITION `p_2026_04_19` VALUES LESS THAN (740091) ENGINE = InnoDB,
 PARTITION `p_2026_04_20` VALUES LESS THAN (740092) ENGINE = InnoDB,
 PARTITION `p_2026_04_21` VALUES LESS THAN (740093) ENGINE = InnoDB,
 PARTITION `p_2026_04_22` VALUES LESS THAN (740094) ENGINE = InnoDB,
 PARTITION `p_2026_04_23` VALUES LESS THAN (740095) ENGINE = InnoDB,
 PARTITION `p_2026_04_24` VALUES LESS THAN (740096) ENGINE = InnoDB,
 PARTITION `p_2026_04_25` VALUES LESS THAN (740097) ENGINE = InnoDB,
 PARTITION `p_2026_04_26` VALUES LESS THAN (740098) ENGINE = InnoDB,
 PARTITION `p_2026_04_27` VALUES LESS THAN (740099) ENGINE = InnoDB,
 PARTITION `p_2026_04_28` VALUES LESS THAN (740100) ENGINE = InnoDB);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mail_messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mail_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `body` text NOT NULL,
  `time` datetime NOT NULL,
  `readed` tinyint(1) NOT NULL DEFAULT 0,
  `from_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `to_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `from_id` (`from_id`),
  KEY `to_id` (`to_id`),
  CONSTRAINT `mail_messages_ibfk_1` FOREIGN KEY (`from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mail_messages_ibfk_2` FOREIGN KEY (`to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=378 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'id of user who added member',
  `registration` tinyint(1) NOT NULL,
  `registration_target_type` tinyint(3) unsigned DEFAULT 2,
  `name` varchar(255) NOT NULL,
  `address_point_id` int(11) NOT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `external_type` tinyint(4) DEFAULT NULL,
  `organization_identifier` varchar(20) DEFAULT NULL,
  `vat_organization_identifier` varchar(30) DEFAULT NULL,
  `speed_class_id` int(11) DEFAULT NULL,
  `entrance_fee` double DEFAULT NULL,
  `debt_payment_rate` double DEFAULT NULL,
  `entrance_fee_left` double DEFAULT NULL,
  `entrance_fee_date` date DEFAULT NULL,
  `entrance_date` date DEFAULT NULL,
  `entrance_form_received` date DEFAULT NULL,
  `entrance_form_accepted` date DEFAULT NULL,
  `leaving_date` date NOT NULL,
  `oku_code` char(14) DEFAULT NULL,
  `applicant_registration_datetime` datetime DEFAULT NULL COMMENT 'Used only for members who were registered by registration form by them self.',
  `applicant_connected_from` date DEFAULT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT 0,
  `voip_billing_limit` int(11) NOT NULL DEFAULT 0,
  `voip_billing_type` varchar(10) NOT NULL DEFAULT 'prepaid',
  `comment` varchar(250) DEFAULT NULL,
  `notification_by_redirection` tinyint(4) NOT NULL DEFAULT 1,
  `notification_by_email` tinyint(4) NOT NULL DEFAULT 1,
  `notification_by_sms` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_oku_code` (`oku_code`),
  KEY `address_point_id` (`address_point_id`),
  KEY `user_id` (`user_id`),
  KEY `speed_class_id_fk` (`speed_class_id`),
  CONSTRAINT `members_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `members_ibfk_2` FOREIGN KEY (`address_point_id`) REFERENCES `address_points` (`id`),
  CONSTRAINT `members_ibfk_3` FOREIGN KEY (`speed_class_id`) REFERENCES `speed_classes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9817 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_domiciles`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_domiciles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `address_point_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`,`address_point_id`),
  KEY `address_point_id` (`address_point_id`),
  CONSTRAINT `members_domiciles_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_domiciles_ibfk_2` FOREIGN KEY (`address_point_id`) REFERENCES `address_points` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_fees`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_fees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `activation_date` date NOT NULL DEFAULT '0000-00-00',
  `deactivation_date` date DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 1,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `fee_id` (`fee_id`),
  KEY `activation_date` (`activation_date`,`deactivation_date`),
  CONSTRAINT `members_fees_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_fees_ibfk_2` FOREIGN KEY (`fee_id`) REFERENCES `fees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20195 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Junction table between fees and members, used primarily for ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_traffics_daily`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_traffics_daily` (
  `member_id` int(11) NOT NULL,
  `upload` bigint(20) unsigned NOT NULL,
  `download` bigint(20) unsigned NOT NULL,
  `local_upload` bigint(20) unsigned NOT NULL,
  `local_download` bigint(20) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `date` date NOT NULL,
  PRIMARY KEY (`member_id`,`date`),
  KEY `member_id` (`member_id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci
 PARTITION BY RANGE (to_days(`date`))
(PARTITION `p_first` VALUES LESS THAN (719528) ENGINE = InnoDB,
 PARTITION `p_2016_02_26` VALUES LESS THAN (736386) ENGINE = InnoDB,
 PARTITION `p_2016_02_27` VALUES LESS THAN (736387) ENGINE = InnoDB,
 PARTITION `p_2016_02_28` VALUES LESS THAN (736388) ENGINE = InnoDB,
 PARTITION `p_2016_02_29` VALUES LESS THAN (736389) ENGINE = InnoDB,
 PARTITION `p_2016_03_01` VALUES LESS THAN (736390) ENGINE = InnoDB,
 PARTITION `p_2016_03_02` VALUES LESS THAN (736391) ENGINE = InnoDB,
 PARTITION `p_2016_03_03` VALUES LESS THAN (736392) ENGINE = InnoDB,
 PARTITION `p_2016_03_04` VALUES LESS THAN (736393) ENGINE = InnoDB);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_traffics_monthly`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_traffics_monthly` (
  `member_id` int(11) NOT NULL,
  `upload` bigint(20) unsigned NOT NULL,
  `download` bigint(20) unsigned NOT NULL,
  `local_upload` bigint(20) unsigned NOT NULL,
  `local_download` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`member_id`,`date`),
  KEY `member_id` (`member_id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci
 PARTITION BY RANGE (to_days(`date`))
(PARTITION `p_first` VALUES LESS THAN (719528) ENGINE = InnoDB,
 PARTITION `p_2016_03_01` VALUES LESS THAN (736420) ENGINE = InnoDB);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_traffics_yearly`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_traffics_yearly` (
  `member_id` int(11) NOT NULL,
  `upload` bigint(20) unsigned NOT NULL,
  `download` bigint(20) unsigned NOT NULL,
  `local_upload` bigint(20) unsigned NOT NULL,
  `local_download` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`member_id`,`date`),
  KEY `member_id` (`member_id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_whitelists`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_whitelists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `permanent` tinyint(1) NOT NULL,
  `since` date NOT NULL,
  `until` date NOT NULL,
  `comment` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `since_index` (`since`),
  KEY `until` (`until`),
  KEY `member_id_fk` (`member_id`),
  CONSTRAINT `members_whitelists_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1307 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Redirection member white list.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `membership_interrupts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_interrupts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `members_fee_id` int(11) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `end_after_interrupt_end` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `members_fee_id` (`members_fee_id`),
  CONSTRAINT `membership_interrupts_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `membership_interrupts_ibfk_2` FOREIGN KEY (`members_fee_id`) REFERENCES `members_fees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=620 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `membership_transfers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_member_id` int(11) NOT NULL,
  `to_member_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `from_member_id` (`from_member_id`),
  KEY `to_member_id` (`to_member_id`),
  CONSTRAINT `membership_transfers_ibfk_1` FOREIGN KEY (`to_member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `membership_transfers_ibfk_2` FOREIGN KEY (`from_member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT 'Name of the redirection message',
  `text` text DEFAULT NULL COMMENT 'Content of message, can contain HTML code.',
  `email_text` text DEFAULT NULL,
  `sms_text` varchar(760) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT 'Types of messages are saved in Mesage_Model.',
  `self_cancel` tinyint(4) DEFAULT NULL COMMENT 'Possibility of self-canceling of redirection message.',
  `ignore_whitelist` tinyint(4) DEFAULT 0 COMMENT 'If set, than IP address in whitelist are also redirected.',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='messages used for redirection';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `messages_automatical_activations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages_automatical_activations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `redirection_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `email_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `sms_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `send_activation_to_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `message_id_fk` (`message_id`),
  CONSTRAINT `messages_automatical_activations_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `messages_ip_addresses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages_ip_addresses` (
  `message_id` int(11) NOT NULL COMMENT 'redirection message',
  `ip_address_id` int(11) NOT NULL COMMENT 'redirected ip address',
  `user_id` int(11) DEFAULT NULL COMMENT 'user id of admin who redirects',
  `comment` text DEFAULT NULL COMMENT 'personal comment from admin for redirected user',
  `datetime` datetime NOT NULL COMMENT 'Date and time of setting redirection',
  PRIMARY KEY (`message_id`,`ip_address_id`),
  KEY `user_id` (`user_id`),
  KEY `ip_address_id` (`ip_address_id`),
  CONSTRAINT `messages_ip_addresses_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_ip_addresses_ibfk_2` FOREIGN KEY (`ip_address_id`) REFERENCES `ip_addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_ip_addresses_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `messages_ip_addresses_ibfk_4` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_ip_addresses_ibfk_5` FOREIGN KEY (`ip_address_id`) REFERENCES `ip_addresses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='junction table between redirected ip address and message of ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `monitor_hosts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitor_hosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `state_changed` tinyint(1) NOT NULL,
  `state_changed_date` datetime NOT NULL,
  `last_attempt_date` datetime NOT NULL,
  `last_notification_date` datetime DEFAULT NULL,
  `latency_current` float DEFAULT NULL,
  `latency_min` float DEFAULT NULL,
  `latency_max` float DEFAULT NULL,
  `latency_avg` float DEFAULT NULL,
  `polls_total` bigint(11) NOT NULL,
  `polls_failed` bigint(11) NOT NULL,
  `availability` float NOT NULL,
  `priority` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  CONSTRAINT `monitor_hosts_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `onts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `onts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `serial` varchar(64) NOT NULL,
  `gpon_port` varchar(64) NOT NULL,
  `port_num` tinyint(3) unsigned NOT NULL,
  `port_index` bigint(20) DEFAULT NULL,
  `ont_id` int(10) unsigned NOT NULL,
  `service_port` int(10) unsigned NOT NULL,
  `vlan` int(10) unsigned NOT NULL,
  `reg_status` enum('new','registered','removed') NOT NULL DEFAULT 'new',
  `house_no` varchar(32) DEFAULT NULL,
  `user_name` varchar(128) DEFAULT NULL,
  `olt_ip` varchar(45) DEFAULT NULL,
  `gps_lat` decimal(10,7) DEFAULT NULL,
  `gps_lng` decimal(10,7) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `onts_member_id_foreign` (`member_id`),
  KEY `onts_device_id_foreign` (`device_id`),
  KEY `onts_serial_index` (`serial`),
  KEY `onts_olt_ip_index` (`olt_ip`),
  CONSTRAINT `onts_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `onts_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `outgoing_payments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outgoing_payments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bank_account_id` int(11) unsigned NOT NULL COMMENT 'our bank account (from which we pay)',
  `transfer_id` int(11) unsigned DEFAULT NULL,
  `target_account` varchar(34) NOT NULL COMMENT 'e.g. 123456789/2010',
  `target_name` varchar(128) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'CZK',
  `variable_symbol` varchar(20) DEFAULT NULL,
  `message` varchar(140) NOT NULL,
  `reason` enum('unidentified_refund','termination_refund','other') NOT NULL DEFAULT 'other',
  `status` enum('draft','approved','exported','paid','cancelled') NOT NULL DEFAULT 'draft',
  `created_by` int(11) unsigned NOT NULL,
  `approved_by` int(11) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `export_ref` varchar(64) DEFAULT NULL,
  `exported_at` datetime DEFAULT NULL,
  `export_filename` varchar(255) DEFAULT NULL,
  `api_response` text DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `paid_transfer_id` int(10) unsigned DEFAULT NULL,
  `match_method` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_transfer_refund` (`transfer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_bank_account_id` (`bank_account_id`),
  KEY `idx_reason` (`reason`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_calls`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_calls` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Call started at',
  `price` float NOT NULL,
  `length` time NOT NULL,
  `number` varchar(15) NOT NULL COMMENT 'Called',
  `period` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `private` tinyint(1) DEFAULT 1 COMMENT 'Was call private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  KEY `number` (`number`),
  CONSTRAINT `phone_calls_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_calls_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of call service of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_connections`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_connections` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Connection started at',
  `price` float NOT NULL,
  `transfered` int(11) NOT NULL COMMENT 'In kB',
  `period` varchar(100) DEFAULT NULL,
  `apn` varchar(100) DEFAULT NULL,
  `private` tinyint(1) DEFAULT 1 COMMENT 'Was it private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  CONSTRAINT `phone_connections_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_connections_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of data service(internet connection) of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_fixed_calls`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_fixed_calls` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Call started at',
  `price` float NOT NULL,
  `length` time NOT NULL,
  `number` varchar(15) NOT NULL COMMENT 'Called',
  `period` varchar(100) DEFAULT NULL,
  `destiny` varchar(200) DEFAULT NULL,
  `private` tinyint(1) DEFAULT 1 COMMENT 'Was fised call private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  KEY `number` (`number`),
  CONSTRAINT `phone_fixed_calls_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_fixed_calls_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of fixed call service of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_invoice_users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_invoice_users` (
  `user_id` int(11) DEFAULT NULL COMMENT 'ID of user or NULL if user was not assigned yet',
  `phone_invoice_id` int(11) NOT NULL,
  `transfer_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(15) NOT NULL COMMENT 'Phone nuber with prefix with leading plus',
  `locked` tinyint(1) unsigned NOT NULL COMMENT 'User locked his invoice as filled in.',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`phone_invoice_id`),
  KEY `phone_invoice_id` (`phone_invoice_id`),
  KEY `phone_number` (`phone_number`),
  KEY `transfer_id` (`transfer_id`),
  CONSTRAINT `phone_invoice_users_ibfk_1` FOREIGN KEY (`phone_invoice_id`) REFERENCES `phone_invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_invoice_users_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_invoice_users_ibfk_3` FOREIGN KEY (`phone_invoice_id`) REFERENCES `phone_invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_invoice_users_ibfk_4` FOREIGN KEY (`transfer_id`) REFERENCES `transfers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of user invoices for phone';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_invoices`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_of_issuance` date NOT NULL,
  `billing_period_from` date NOT NULL,
  `billing_period_to` date NOT NULL,
  `variable_symbol` bigint(11) NOT NULL,
  `specific_symbol` bigint(11) NOT NULL,
  `total_price` float NOT NULL COMMENT 'Price without taxes',
  `tax` float NOT NULL COMMENT 'DPH',
  `tax_rate` smallint(6) NOT NULL COMMENT 'DPH in percents',
  `locked` tinyint(1) DEFAULT 0 COMMENT 'Indicate if invoice is locked for editing from users (not admin)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of phone invoices';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_operator_prefixes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_operator_prefixes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_operator_id` int(11) NOT NULL,
  `prefix` varchar(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prefix` (`prefix`),
  KEY `phone_operator_id` (`phone_operator_id`),
  CONSTRAINT `phone_operator_prefixes_ibfk_1` FOREIGN KEY (`phone_operator_id`) REFERENCES `phone_operators` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_operators`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_operators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` smallint(6) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone_number_length` smallint(2) DEFAULT 6,
  `sms_enabled` tinyint(1) DEFAULT 0 COMMENT 'Allows SMS sendind for this operator?',
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `phone_operators_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_pays`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_pays` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Payed at',
  `price` float NOT NULL,
  `number` varchar(15) NOT NULL COMMENT 'Pay to',
  `description` varchar(200) DEFAULT NULL,
  `private` tinyint(4) DEFAULT 1 COMMENT 'Was pay private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  KEY `number` (`number`),
  CONSTRAINT `phone_pays_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_pays_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of pays of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_roaming_sms_messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_roaming_sms_messages` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Message send at',
  `price` float NOT NULL,
  `roaming_zone` varchar(200) DEFAULT NULL,
  `private` tinyint(4) DEFAULT 1 COMMENT 'Was message private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  CONSTRAINT `phone_roaming_sms_messages_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_roaming_sms_messages_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of sms messages service of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_sms_messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_sms_messages` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Message send at',
  `price` float NOT NULL,
  `number` varchar(15) NOT NULL COMMENT 'Send to',
  `period` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `private` tinyint(4) DEFAULT 1 COMMENT 'Was message private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  KEY `number` (`number`),
  CONSTRAINT `phone_sms_messages_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_sms_messages_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of sms messages service of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phone_vpn_calls`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_vpn_calls` (
  `phone_invoice_user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL COMMENT 'Call started at',
  `price` float NOT NULL,
  `length` time NOT NULL,
  `number` varchar(15) NOT NULL COMMENT 'Called to',
  `period` varchar(100) DEFAULT NULL,
  `group` varchar(200) DEFAULT NULL,
  `private` tinyint(1) DEFAULT 1 COMMENT 'Was call private?',
  PRIMARY KEY (`id`),
  KEY `phone_invoice_users_id` (`phone_invoice_user_id`),
  KEY `datetime` (`datetime`),
  KEY `number` (`number`),
  CONSTRAINT `phone_vpn_calls_ibfk_1` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phone_vpn_calls_ibfk_2` FOREIGN KEY (`phone_invoice_user_id`) REFERENCES `phone_invoice_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Table of vpn call service of phone invoice';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pohoda_refund_queue`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pohoda_refund_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `member_type` int(11) NOT NULL,
  `doc_number` varchar(20) NOT NULL,
  `outgoing_payment_id` int(11) DEFAULT NULL,
  `refund_account` varchar(64) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'CZK',
  `reason` varchar(32) NOT NULL DEFAULT 'termination_refund',
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `exported_at` datetime DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'new',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `member_id` (`member_id`),
  KEY `idx_doc_number` (`doc_number`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `private_users_contacts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `private_users_contacts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL COMMENT 'User who has private contact',
  `contact_id` int(10) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`contact_id`),
  KEY `private_users_contacts_ibfk_2` (`contact_id`),
  CONSTRAINT `private_users_contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `private_users_contacts_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Private address book of each user';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `public_ip_nat_1to1`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_ip_nat_1to1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `public_ip` varchar(45) NOT NULL,
  `private_ip` varchar(45) DEFAULT NULL,
  `scope` varchar(64) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `comment` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `modified_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_public_scope` (`public_ip`,`scope`),
  KEY `idx_enabled` (`enabled`),
  KEY `idx_scope` (`scope`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `public_ips`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_ips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `note` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `modified_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ip` (`ip`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `public_port_forwards`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_port_forwards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `public_ip` varchar(45) NOT NULL,
  `public_port_from` int(10) unsigned NOT NULL,
  `public_port_to` int(10) unsigned NOT NULL,
  `private_ip` varchar(45) NOT NULL,
  `private_port_from` int(10) unsigned NOT NULL,
  `private_port_to` int(10) unsigned NOT NULL,
  `protocol` enum('tcp','udp') NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `modified_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_public` (`public_ip`,`protocol`,`public_port_from`),
  KEY `idx_private` (`private_ip`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `requests`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `approval_template_id` int(11) DEFAULT NULL,
  `type` smallint(6) NOT NULL DEFAULT 0,
  `description` mediumtext DEFAULT NULL,
  `suggest_amount` int(11) NOT NULL COMMENT 'suggest amount by user',
  `date` date NOT NULL,
  `state` tinyint(1) NOT NULL,
  `comments_thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `comments_thread_id` (`comments_thread_id`),
  KEY `approval_template_id` (`approval_template_id`),
  CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`approval_template_id`) REFERENCES `approval_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `requests_ibfk_3` FOREIGN KEY (`comments_thread_id`) REFERENCES `comments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `saved_filters`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_filters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `page` varchar(50) NOT NULL,
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`filters`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_messages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `sms_message_id` int(11) DEFAULT NULL,
  `stamp` datetime NOT NULL,
  `send_date` datetime NOT NULL,
  `text` varchar(800) NOT NULL,
  `sender` varchar(14) NOT NULL,
  `receiver` varchar(14) NOT NULL,
  `driver` tinyint(4) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `state` tinyint(4) NOT NULL,
  `message` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `sms_message_id` (`sms_message_id`),
  KEY `sender` (`sender`),
  KEY `receiver` (`receiver`),
  CONSTRAINT `sms_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sms_messages_ibfk_2` FOREIGN KEY (`sms_message_id`) REFERENCES `sms_messages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=40574 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `smtp_exceptions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `smtp_exceptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `intip` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `user` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `datum` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `speed_classes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `speed_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `d_ceil` bigint(11) NOT NULL COMMENT 'QoS download ceil in bytes',
  `d_rate` bigint(11) NOT NULL COMMENT 'QoS download rate in bytes',
  `u_ceil` bigint(11) NOT NULL COMMENT 'QoS upload ceil in bytes',
  `u_rate` bigint(11) NOT NULL COMMENT 'QoS upload rate in bytes',
  `regular_member_default` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Is this class default for regular members?',
  `applicant_default` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Is this class default for applicants?',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Defines speed classes for QoS';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `streets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `streets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `town_id` int(11) DEFAULT NULL,
  `street` varchar(30) NOT NULL,
  `gps` polygon DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `street` (`street`),
  KEY `town_id` (`town_id`),
  CONSTRAINT `streets_ibfk_1` FOREIGN KEY (`town_id`) REFERENCES `towns` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3470 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subnets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subnets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `OSPF_area_id` int(11) DEFAULT NULL,
  `name` varchar(254) DEFAULT NULL,
  `network_address` varchar(15) DEFAULT NULL,
  `netmask` varchar(15) DEFAULT NULL,
  `redirect` tinyint(4) DEFAULT NULL COMMENT 'Bit mask for types of redirect',
  `dhcp` tinyint(1) NOT NULL DEFAULT 0,
  `dhcp_expired` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'If DHCP is enabled on this subnet, this value indicates if any of its record was updated and not synchronized to DHCP server.',
  `dns` tinyint(1) NOT NULL DEFAULT 0,
  `qos` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `network_address` (`network_address`),
  KEY `netmask` (`netmask`)
) ENGINE=InnoDB AUTO_INCREMENT=1486 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subnets_owners`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subnets_owners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subnet_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `redirect` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `redirect` (`redirect`),
  KEY `subnet_id` (`subnet_id`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `subnets_owners_ibfk_1` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subnets_owners_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `towns`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `towns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zip_code` varchar(10) NOT NULL,
  `town` varchar(50) NOT NULL,
  `quarter` varchar(50) DEFAULT NULL,
  `gps` polygon DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `town` (`town`),
  KEY `zip_code` (`zip_code`)
) ENGINE=InnoDB AUTO_INCREMENT=665 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transfers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `origin_id` int(11) DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `previous_transfer_id` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL COMMENT 'id of the member, to whom the transaction is assigned',
  `user_id` int(11) DEFAULT NULL COMMENT 'id of user, who added transfer',
  `type` tinyint(4) DEFAULT NULL,
  `datetime` datetime NOT NULL,
  `creation_datetime` datetime NOT NULL,
  `text` varchar(254) DEFAULT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `datetime` (`datetime`,`text`),
  KEY `origin_id` (`origin_id`),
  KEY `destination_id` (`destination_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transfers_ibfk_1` FOREIGN KEY (`origin_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transfers_ibfk_2` FOREIGN KEY (`destination_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transfers_ibfk_3` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transfers_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1064185 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `translations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_term` varchar(254) NOT NULL,
  `translated_term` varchar(254) NOT NULL,
  `lang` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `original_term` (`original_term`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ulog2_ct`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ulog2_ct` (
  `_ct_id` tinyint(4) DEFAULT NULL,
  `orig_ip_saddr` int(10) unsigned DEFAULT NULL,
  `orig_ip_daddr` int(10) unsigned DEFAULT NULL,
  `orig_ip_protocol` tinyint(3) unsigned DEFAULT NULL,
  `orig_l4_sport` smallint(5) unsigned DEFAULT NULL,
  `orig_l4_dport` smallint(5) unsigned DEFAULT NULL,
  `orig_raw_pktlen` bigint(20) DEFAULT 0,
  `orig_raw_pktcount` int(10) unsigned DEFAULT 0,
  `reply_ip_daddr` int(10) unsigned DEFAULT NULL,
  `reply_l4_dport` smallint(5) unsigned DEFAULT NULL,
  `reply_raw_pktlen` bigint(20) DEFAULT 0,
  `reply_raw_pktcount` int(10) unsigned DEFAULT 0,
  `icmp_code` tinyint(3) DEFAULT NULL,
  `icmp_type` tinyint(3) DEFAULT NULL,
  `flow_start_sec` int(10) DEFAULT 0,
  `flow_end_sec` int(10) DEFAULT 0,
  KEY `ct_tuple` (`flow_start_sec`,`orig_ip_daddr`,`orig_l4_dport`,`reply_l4_dport`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_favourite_pages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_favourite_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(30) NOT NULL,
  `title` varchar(50) NOT NULL,
  `page` varchar(255) NOT NULL,
  `default_page` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_favourite_pages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `member_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `password_request` varchar(10) DEFAULT NULL,
  `password_request_expires_at` datetime DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `middle_name` varchar(30) DEFAULT NULL,
  `surname` varchar(60) DEFAULT NULL,
  `pre_title` varchar(40) DEFAULT NULL,
  `post_title` varchar(30) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `type` tinyint(4) NOT NULL,
  `comment` varchar(250) DEFAULT NULL,
  `application_password` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  KEY `name` (`name`),
  KEY `surname` (`surname`),
  KEY `member_id` (`member_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9841 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users_contacts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_contacts` (
  `user_id` int(10) NOT NULL,
  `contact_id` int(10) NOT NULL,
  `mail_redirection` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'In condition that this contact is an e-mail, this indicator specifies whether the inner system mail is redirected to this user''s e-mail box.',
  PRIMARY KEY (`user_id`,`contact_id`),
  KEY `users_contacts_ibfk_2` (`contact_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `users_contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_contacts_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci COMMENT='Pivot table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users_keys`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `key` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `users_keys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users_to_members`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_to_members` (
  `userid` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variable_symbols`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `variable_symbols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `variable_symbol` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `variable_symbol` (`variable_symbol`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `variable_symbols_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5410 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vlans`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(254) DEFAULT NULL,
  `tag_802_1q` int(11) DEFAULT NULL,
  `comment` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_802_1q` (`tag_802_1q`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=593 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `voip_sips`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voip_sips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `accountcode` varchar(20) DEFAULT NULL,
  `amaflags` varchar(13) DEFAULT NULL,
  `callgroup` varchar(10) DEFAULT NULL,
  `callerid` varchar(80) NOT NULL,
  `canreinvite` char(3) DEFAULT 'no',
  `context` varchar(80) DEFAULT 'internal',
  `defaultip` varchar(15) DEFAULT NULL,
  `dtmfmode` varchar(7) DEFAULT NULL,
  `fromuser` varchar(80) DEFAULT NULL,
  `fromdomain` varchar(80) DEFAULT NULL,
  `fullcontact` varchar(80) DEFAULT NULL,
  `host` varchar(31) NOT NULL DEFAULT 'dynamic',
  `insecure` varchar(4) DEFAULT NULL,
  `language` char(2) DEFAULT 'cz',
  `mailbox` varchar(50) NOT NULL,
  `md5secret` varchar(80) DEFAULT NULL,
  `nat` varchar(5) NOT NULL DEFAULT 'yes',
  `deny` varchar(95) DEFAULT NULL,
  `permit` varchar(95) DEFAULT NULL,
  `mask` varchar(95) DEFAULT NULL,
  `pickupgroup` varchar(10) DEFAULT NULL,
  `port` varchar(5) DEFAULT NULL,
  `qualify` char(3) DEFAULT NULL,
  `restrictcid` char(1) DEFAULT NULL,
  `rtptimeout` char(3) DEFAULT NULL,
  `rtpholdtimeout` char(3) DEFAULT NULL,
  `secret` varchar(80) NOT NULL,
  `type` varchar(6) NOT NULL DEFAULT 'friend',
  `username` varchar(80) NOT NULL,
  `disallow` varchar(100) DEFAULT NULL,
  `allow` varchar(100) DEFAULT NULL,
  `musiconhold` varchar(100) DEFAULT NULL,
  `regseconds` int(11) NOT NULL DEFAULT 0,
  `ipaddr` varchar(15) NOT NULL,
  `regexten` varchar(80) NOT NULL,
  `cancallforward` char(3) DEFAULT 'yes',
  `setvar` varchar(100) NOT NULL,
  `auth` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `voip_sips_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `voip_voicemail_users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voip_voicemail_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT 1,
  `context` varchar(50) NOT NULL,
  `mailbox` varchar(10) NOT NULL DEFAULT '0',
  `password` varchar(4) NOT NULL DEFAULT '0',
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pager` varchar(50) NOT NULL,
  `stamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `votes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'id of voter',
  `type` int(11) NOT NULL COMMENT 'type of vote',
  `fk_id` int(11) NOT NULL COMMENT 'id of foreign key',
  `aro_group_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `vote` tinyint(1) DEFAULT NULL COMMENT 'value of user vote',
  `time` datetime NOT NULL,
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `fk_id` (`fk_id`),
  KEY `aro_group_id` (`aro_group_id`),
  CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `votes_ibfk_3` FOREIGN KEY (`aro_group_id`) REFERENCES `aro_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `watchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `watchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `fk_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`type`,`fk_id`),
  CONSTRAINT `watchers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-01 17:30:50

-- ── Lookup data ──────────────────────────────────────
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.3-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: freenetis
-- ------------------------------------------------------
-- Server version	11.8.3-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Dumping data for table `axo`
--

LOCK TABLES `axo` WRITE;
/*!40000 ALTER TABLE `axo` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (0,'Network_Controller','public_ip_nat','public_ip_nat');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (1,'Network_Controller','public_ports','public_ports');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (20,'Members_Controller','comment','Comment');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (21,'Members_Controller','entrance_date','Entrance date');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (22,'Members_Controller','qos_ceil','QoS ceil');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (23,'Members_Controller','qos_rate','QoS rate');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (55,'Accounts_Controller','invoices','Invoices');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (91,'Members_Controller','members','Members');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (92,'Users_Controller','additional_contacts','Additional contacts');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (93,'Users_Controller','users','Users');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (95,'Accounts_Controller','transfers','Transfers');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (96,'Accounts_Controller','accounts','Accounts');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (97,'Users_Controller','login','Login');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (98,'Members_Controller','name','Name');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (100,'Members_Controller','type','Type');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (103,'Members_Controller','address','Address');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (106,'Members_Controller','currentcredit','Current credit');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (107,'Members_Controller','en_fee','Entrance fee');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (109,'Members_Controller','debit','Debit');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (111,'Works_Controller','work','Work');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (112,'Users_Controller','comment','Comment');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (113,'Users_Controller','password','Password');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (115,'Devices_Controller','devices','Devices');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (116,'Devices_Controller','admin','Admin');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (117,'Ifaces_Controller','iface','Interface');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (119,'Ip_addresses_Controller','ip_address','IP address');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (121,'Links_Controller','link','Link');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (122,'Vlans_Controller','vlan','VLAN');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (123,'Subnets_Controller','subnet','Subnet');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (124,'Members_Controller','registration','Registration');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (126,'Translations_Controller','translation','Translation');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (128,'Users_Controller','member','Member');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (129,'Members_Controller','membership_interrupts','Membership interrupts');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (132,'Members_Controller','organization_id','Organization identifier');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (133,'Members_Controller','leaving_date','Leaving date');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (134,'Accounts_Controller','bank_transfers','Bank transfers');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (135,'Accounts_Controller','bank_accounts','Bank accounts');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (136,'Accounts_Controller','unidentified_transfers','Unidentified transfers');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (139,'Devices_Controller','engineer','Engineer');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (140,'Address_points_Controller','address_point','Address point');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (142,'Address_points_Controller','town','Town');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (143,'Address_points_Controller','street','Street');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (145,'Subnets_Controller','redirect','Redirection of subnet');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (146,'VoIP_Controller','voip','VoIP');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (147,'VoIP_Controller','voip_password','VoIP password');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (148,'Tools_Controller','tools','Tools');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (149,'Users_Controller','application_password','Application password');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (150,'Members_Controller','locked','Locked account');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (153,'Members_Controller','user_id','User who added member to system');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (154,'Messages_Controller','message','Message used for redirection');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (156,'Messages_Controller','member','Redirection of IP addresses of member');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (160,'approval','templates','Approval templates');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (161,'approval','template_items','Approval template items');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (162,'approval','types','Approval types');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (163,'Accounts_Controller','bank_statements','Bank statements');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (164,'Phone_invoices_Controller','invoices','Invoices');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (165,'Phone_invoices_Controller','lock','Lock');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (166,'Phone_invoices_Controller','pay','Pay');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (167,'Phone_invoices_Controller','details','Details');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (168,'Phone_invoices_Controller','dumps','Dumps');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (169,'Private_phone_contacts_Controller','contacts','contacts');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (170,'Phone_invoices_Controller','mail_warning','Mail warning');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (171,'Members_Controller','fees','Member\'s fees');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (172,'Ulogd_Controller','ip_address','IP address');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (173,'Ulogd_Controller','member','Member');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (174,'Comments_Controller','works','');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (175,'Allowed_subnets_Controller','allowed_subnet','Allowed subnet');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (176,'Users_Controller','keys','Keys (SSH)');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (177,'Clouds_Controller','clouds','Clouds');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (178,'Variable_Symbols_Controller','variable_symbols','Variable symbols');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (179,'Logs_Controller','logs','Logs');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (180,'Login_logs_Controller','logs','Login logs');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (181,'Connection_Requests_Controller','request','Connection request');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (182,'Requests_Controller','request','Request');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (183,'Requests_Controller','approval_template','Approval template of request');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (184,'Work_reports_Controller','work_report','Work report');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (185,'Work_reports_Controller','approval_template','Approval template of work report');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (186,'Comments_Controller','requests','Comments for request');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (187,'Works_Controller','approval_template','Approval template of work');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (188,'Log_queues_Controller','log_queue','Log queues');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (189,'Log_queues_Controller','comments','Comments for log queue');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (190,'Membership_transfers_Controller','membership_transfer','Transfer of membership');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (191,'Monitoring_Controller','monitoring','Monitoring');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (192,'Device_logs_Controller','device_log','Logs from devices');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (193,'Devices_Controller','export','Export of device');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (194,'Devices_Controller','map','Map of devices');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (195,'Ifaces_Controller','link','Link of ifaces');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (197,'Messages_Controller','auto_config','Messages auto activation configuration');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (198,'Accounts_Controller','bank_account_auto_down_config','Bank account configuration for automatical download of statements');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (199,'Stats_Controller','members_increase_decrease','Members increase decrease');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (200,'Stats_Controller','members_growth','Members growth');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (201,'Stats_Controller','incoming_member_payment','Incoming member payment');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (202,'Stats_Controller','members_fees','Members fees');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (203,'Devices_Controller','topology','Topology of device');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (204,'Notifications_Controller','member','Member notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (205,'Notifications_Controller','members','Members notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (206,'Notifications_Controller','subnet','Subnet notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (207,'Notifications_Controller','cloud','Cloud notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (208,'Messages_Controller','activate','Activate message');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (209,'Messages_Controller','deactivate','Deactivate message');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (210,'Messages_Controller','preview','Preview message');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (211,'Redirect_Controller','redirect','Redirection');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (212,'Members_whitelists_Controller','whitelist','Whitelist');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (213,'Sms_Controller','sms','SMS');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (214,'Ulogd_Controller','total','Total');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (215,'Email_queues_Controller','email_queue','E-mail queue');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (216,'Device_templates_Controller','device_template','Device template');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (217,'Fees_Controller','fees','Fees');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (218,'Acl_Controller','acl','ACL');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (219,'Aro_groups_Controller','aro_group','ARO Group');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (220,'Enum_types_Controller','enum_types','Enumeration types');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (221,'Speed_classes_Controller','speed_classes','Speed classes');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (222,'Phone_operators_Controller','phone_operators','Phone operators');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (223,'Filter_queries_Controller','filter_queries','Filter queries');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (224,'Settings_Controller','info','Info');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (225,'Settings_Controller','system_settings','System settings');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (226,'Settings_Controller','users_settings','Users settings');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (227,'Settings_Controller','finance_settings','Finance');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (228,'Settings_Controller','approval_settings','Approval');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (229,'Settings_Controller','networks_settings','Networks');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (230,'Settings_Controller','email_settings','E-mail');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (231,'Settings_Controller','sms_settings','SMS');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (232,'Settings_Controller','voip_settings','VoIP');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (233,'Settings_Controller','notification_settings','Notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (234,'Settings_Controller','qos_settings','QoS');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (235,'Settings_Controller','monitoring_settings','Monitoring');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (236,'Settings_Controller','vtiger_settings','Vtiger');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (237,'Settings_Controller','logging_settings','Logging');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (238,'Users_Controller','additional_contacts_admin_delete','Additional contacts administrator delete');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (239,'Export_Controller','all_tables','Export all tables to csv');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (240,'Subnets_Controller','dhcp','DHCP server on subnet');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (241,'Subnets_Controller','qos','QoS on subnet');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (242,'Subnets_Controller','dns','DNS server on subnet');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (243,'Members_Controller','vat_organization_identifier','VAT organization identifier');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (244,'Devices_Controller','login','Device login name');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (245,'Devices_Controller','password','Device password');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (246,'Phone_invoices_Controller','user_invoices','User phone invoices');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (247,'Devices_Controller','main_engineer','Main engineer');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (248,'Device_active_links_Controller','active_links','Device active links');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (249,'Device_active_links_Controller','display_device_active_links','Display device active links');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (250,'Notifications_Controller','device','Device admins notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (251,'Notifications_Controller','devices','Devices admins notification');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (252,'Devices_Controller','ports_vlans_settings','Ports and VLANs settings of device');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (253,'Members_Controller','registration_export','Export of registration');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (254,'Members_Controller','notification_settings','Member notification settings');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (255,'Gpon_Controller','gpon','GPON správa');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (256,'Gpon_Controller','olt','OLT zařízení');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (257,'Gpon_Controller','ont','ONT zařízení');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (258,'Contracts_Controller','contract','Smlouva');
INSERT INTO `axo` (`id`, `section_value`, `value`, `name`) VALUES (259,'Network_Controller','smtp_exceptions','SMTP výjimky');
/*!40000 ALTER TABLE `axo` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `axo_sections`
--

LOCK TABLES `axo_sections` WRITE;
/*!40000 ALTER TABLE `axo_sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (13,'Members_Controller','Regular members');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (14,'Users_Controller','Users of regular members');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (16,'Accounts_Controller','Accounts, transfers, bank accounts and bank transfers');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (17,'Devices_Controller','Devices and other dependent objects');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (18,'Translations_Controller','Translations');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (19,'Settings_Controller','Settings');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (20,'Address_points_Controller','Address points');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (21,'VoIP_Controller','Voip');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (22,'Messages_Controller','Controller used for handling messages for redirection including setting redirection for IP addresses, members and subnets.');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (24,'Phone_invoices_Controller','Phone invoice managing');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (25,'Private_phone_contacts_Controller','Private phone contacts managing');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (26,'Ulogd_Controller','Network traffics of ip addresses and members');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (27,'Clouds_Controller','Clouds managing');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (28,'Variable_Symbols_Controller','Variable symbols managing');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (29,'Logs_Controller','Logs of operations on data');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (30,'Login_logs_Controller','Logs of operations on data');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (31,'Connection_Requests_Controller','Connection requests handling');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (32,'Stats_Controller','Stats');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (33,'Notifications_Controller','Notifications');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (34,'Redirect_Controller','Redirection');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (35,'Members_Whitelists_Controller','Members Whitelists');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (36,'Sms_Controller','SMS');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (37,'Email_queues_Controller','Email queues');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (38,'Fees_Controller','Fees');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (39,'Acl_Controller','ACL');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (40,'Aro_groups_Controller','ARO Groups');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (41,'Enum_types_Controller','Enumeration types');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (42,'Phone_operators_Controller','Phone oprators');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (43,'Filter_queries_Controller','Filter queries');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (44,'Export_Controller','Export');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (45,'Device_templates_Controller','Device templates');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (46,'Speed_classes_Controller','Speed classes');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (47,'Gpon_Controller','GPON');
INSERT INTO `axo_sections` (`id`, `value`, `name`) VALUES (48,'Contracts_Controller','Smlouvy');
/*!40000 ALTER TABLE `axo_sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `aco`
--

LOCK TABLES `aco` WRITE;
/*!40000 ALTER TABLE `aco` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (14,'view_all','Viewing of all records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (15,'edit_all','Editing of all records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (16,'new_all','Creating of all records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (17,'view_own','Viewing of own records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (18,'edit_own','Editing of own records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (19,'new_own','Creating of own records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (20,'delete_all','Deleting of all records');
INSERT INTO `aco` (`id`, `value`, `name`) VALUES (21,'delete_own','Deleting of own records');
/*!40000 ALTER TABLE `aco` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `aco_map`
--

LOCK TABLES `aco_map` WRITE;
/*!40000 ALTER TABLE `aco_map` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (38,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (38,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (38,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (38,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (40,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (43,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (44,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (47,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (47,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (47,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (47,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (49,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (49,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (49,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (49,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (51,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (51,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (51,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (51,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (52,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (54,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (54,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (54,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (56,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (57,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (57,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (57,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (57,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (58,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (58,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (59,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (59,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (60,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (60,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (60,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (60,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (63,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (63,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (63,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (63,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (63,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (64,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (64,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (64,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (64,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (65,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (66,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (68,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (69,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (69,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (69,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (69,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (70,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (71,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (71,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (71,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (71,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (74,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (75,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (76,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (76,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (77,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (77,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (77,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (78,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (78,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (78,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (78,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (79,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (79,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (79,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (79,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (80,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (80,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (81,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (81,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (81,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (81,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (81,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (81,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (82,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (82,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (83,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (83,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (85,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (86,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (87,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (88,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (88,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (88,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (88,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (89,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (89,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (90,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (91,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (91,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (92,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (92,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (93,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (94,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (94,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (94,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (94,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (95,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (95,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (96,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (97,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (97,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (97,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (98,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (98,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (99,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (100,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (100,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (100,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (101,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (101,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (102,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (102,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (102,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (102,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (102,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (102,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (103,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (103,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (105,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (105,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (107,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (108,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (109,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (110,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (110,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (110,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (111,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (112,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (112,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (112,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (112,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (113,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (114,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (114,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (114,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (114,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (115,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (116,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (117,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (119,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (119,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (120,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (122,'delete_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (122,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (122,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (122,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (123,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (123,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (125,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (125,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (125,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (127,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (127,'edit_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (127,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (127,'new_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (127,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (127,'view_own');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (128,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (128,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (128,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (128,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (129,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (130,'delete_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (130,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (130,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (130,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (131,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (131,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (131,'view_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (132,'edit_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (132,'new_all');
INSERT INTO `aco_map` (`acl_id`, `value`) VALUES (132,'view_all');
/*!40000 ALTER TABLE `aco_map` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `axo_map`
--

LOCK TABLES `axo_map` WRITE;
/*!40000 ALTER TABLE `axo_map` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','bank_account_auto_down_config');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','bank_accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','bank_statements');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','bank_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','invoices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Accounts_Controller','unidentified_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Acl_Controller','acl');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Address_points_Controller','address_point');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Address_points_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Address_points_Controller','town');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'approval','template_items');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'approval','templates');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'approval','types');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Aro_groups_Controller','aro_group');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Clouds_Controller','clouds');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Comments_Controller','requests');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Comments_Controller','works');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Device_active_links_Controller','active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Device_active_links_Controller','display_device_active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Device_logs_Controller','device_log');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Device_templates_Controller','device_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','main_engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','map');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','ports_vlans_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Devices_Controller','topology');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Email_queues_Controller','email_queue');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Enum_types_Controller','enum_types');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Export_Controller','all_tables');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Fees_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Filter_queries_Controller','filter_queries');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Ifaces_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Log_queues_Controller','comments');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Log_queues_Controller','log_queue');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Login_logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','leaving_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','locked');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','membership_interrupts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','notification_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','registration_export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','type');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','user_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_Controller','vat_organization_identifier');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Members_whitelists_Controller','whitelist');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Membership_transfers_Controller','membership_transfer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Messages_Controller','activate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Messages_Controller','auto_config');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Messages_Controller','deactivate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Messages_Controller','preview');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Monitoring_Controller','monitoring');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Notifications_Controller','cloud');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Notifications_Controller','device');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Notifications_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Notifications_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Notifications_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Notifications_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','details');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','dumps');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','invoices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','lock');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','mail_warning');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','pay');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_invoices_Controller','user_invoices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Phone_operators_Controller','phone_operators');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Private_phone_contacts_Controller','contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Redirect_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Requests_Controller','approval_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','approval_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','email_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','finance_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','info');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','logging_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','monitoring_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','networks_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','notification_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','qos_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','sms_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','system_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','users_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','voip_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Settings_Controller','vtiger_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Sms_Controller','sms');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Speed_classes_Controller','speed_classes');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Stats_Controller','incoming_member_payment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Stats_Controller','members_fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Stats_Controller','members_growth');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Stats_Controller','members_increase_decrease');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Subnets_Controller','dhcp');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Subnets_Controller','dns');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Subnets_Controller','qos');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Tools_Controller','tools');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Translations_Controller','translation');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Ulogd_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Ulogd_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Ulogd_Controller','total');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','additional_contacts_admin_delete');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','keys');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Variable_Symbols_Controller','variable_symbols');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'VoIP_Controller','voip');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'VoIP_Controller','voip_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Work_reports_Controller','approval_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Work_reports_Controller','work_report');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Works_Controller','approval_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (38,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (40,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (40,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (40,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (40,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (40,'VoIP_Controller','voip');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (43,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (44,'Members_Controller','notification_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (44,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (44,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (44,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (44,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (44,'VoIP_Controller','voip_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (47,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Devices_Controller','engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Tools_Controller','tools');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Ulogd_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Ulogd_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (49,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Accounts_Controller','bank_accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Accounts_Controller','bank_statements');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Accounts_Controller','bank_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Accounts_Controller','unidentified_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Address_points_Controller','address_point');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Address_points_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Address_points_Controller','town');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Comments_Controller','requests');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Comments_Controller','works');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Devices_Controller','engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','leaving_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','locked');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','user_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_Controller','vat_organization_identifier');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Members_whitelists_Controller','whitelist');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Translations_Controller','translation');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Work_reports_Controller','work_report');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (51,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Accounts_Controller','bank_statements');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (52,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Accounts_Controller','bank_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Accounts_Controller','invoices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Accounts_Controller','unidentified_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (54,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','bank_account_auto_down_config');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','bank_accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','bank_statements');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','bank_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','invoices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Accounts_Controller','unidentified_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Address_points_Controller','address_point');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Address_points_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Address_points_Controller','town');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Comments_Controller','requests');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Comments_Controller','works');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Device_active_links_Controller','active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Device_active_links_Controller','display_device_active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Device_templates_Controller','device_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','main_engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','map');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','ports_vlans_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Devices_Controller','topology');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Fees_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Login_logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','leaving_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','locked');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','membership_interrupts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','notification_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','registration_export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','type');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','user_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_Controller','vat_organization_identifier');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Members_whitelists_Controller','whitelist');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Membership_transfers_Controller','membership_transfer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Messages_Controller','activate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Messages_Controller','auto_config');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Messages_Controller','deactivate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Messages_Controller','preview');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Redirect_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Settings_Controller','finance_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Settings_Controller','system_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Settings_Controller','users_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Speed_classes_Controller','speed_classes');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Stats_Controller','incoming_member_payment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Stats_Controller','members_fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Stats_Controller','members_growth');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Stats_Controller','members_increase_decrease');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Subnets_Controller','dhcp');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Subnets_Controller','dns');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Subnets_Controller','qos');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Tools_Controller','tools');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','additional_contacts_admin_delete');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','keys');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Variable_Symbols_Controller','variable_symbols');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Work_reports_Controller','work_report');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (56,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (57,'Translations_Controller','translation');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (58,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (59,'Address_points_Controller','address_point');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (59,'Address_points_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (59,'Address_points_Controller','town');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (59,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (59,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (59,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (60,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (62,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (64,'Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (64,'Users_Controller','keys');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (64,'Work_reports_Controller','work_report');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (64,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (65,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (66,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Devices_Controller','engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (68,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (69,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Devices_Controller','admin');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Devices_Controller','engineer');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Tools_Controller','tools');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (70,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (71,'Device_active_links_Controller','active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (71,'Device_active_links_Controller','display_device_active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (71,'Devices_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (71,'Devices_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (74,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (75,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (76,'Comments_Controller','requests');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (76,'Comments_Controller','works');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (77,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (78,'Clouds_Controller','clouds');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (79,'Variable_Symbols_Controller','variable_symbols');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (80,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','bank_accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','bank_statements');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','bank_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','invoices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Accounts_Controller','unidentified_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (81,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Private_phone_contacts_Controller','contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Users_Controller','keys');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (82,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Device_templates_Controller','device_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Notifications_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Notifications_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Subnets_Controller','dhcp');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (83,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (85,'Logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (86,'Login_logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (87,'Login_logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Comments_Controller','requests');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Devices_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Ifaces_Controller','iface');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Ip_addresses_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Links_Controller','link');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (88,'Vlans_Controller','vlan');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (89,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (90,'Allowed_subnets_Controller','allowed_subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (90,'Ulogd_Controller','ip_address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (90,'Ulogd_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Accounts_Controller','bank_accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Accounts_Controller','bank_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Accounts_Controller','unidentified_transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Members_Controller','locked');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Phone_invoices_Controller','pay');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Variable_Symbols_Controller','variable_symbols');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (91,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','leaving_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','locked');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Members_Controller','user_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (92,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Members_Controller','leaving_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Members_Controller','membership_interrupts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (93,'Variable_Symbols_Controller','variable_symbols');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (94,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Accounts_Controller','accounts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','currentcredit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','entrance_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','leaving_date');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','locked');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','membership_interrupts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','type');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Members_Controller','user_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Registration_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Registration_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Registration_Controller','surname');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (95,'Works_Controller','work');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Members_Controller','notification_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Notifications_Controller','cloud');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Notifications_Controller','device');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Notifications_Controller','devices');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Notifications_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Notifications_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Notifications_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Redirect_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (96,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Device_logs_Controller','device_log');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Devices_Controller','export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Devices_Controller','map');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Devices_Controller','topology');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Email_queues_Controller','email_queue');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Export_Controller','all_tables');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Fees_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Log_queues_Controller','log_queue');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Sms_Controller','sms');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Stats_Controller','incoming_member_payment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Stats_Controller','members_fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Stats_Controller','members_growth');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (97,'Stats_Controller','members_increase_decrease');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (98,'Members_Controller','debit');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (98,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (98,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Comments_Controller','works');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Filter_queries_Controller','filter_queries');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','additional_contacts');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','additional_contacts_admin_delete');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','application_password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','keys');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','login');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','password');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (99,'Users_Controller','users');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (100,'Messages_Controller','activate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (100,'Messages_Controller','deactivate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (100,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (100,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (100,'Messages_Controller','preview');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (101,'Accounts_Controller','transfers');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (101,'Members_Controller','en_fee');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (101,'Members_Controller','fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (102,'Comments_Controller','requests');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (102,'Comments_Controller','works');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (102,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (102,'Users_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (103,'Stats_Controller','incoming_member_payment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (103,'Stats_Controller','members_fees');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (103,'Stats_Controller','members_growth');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (103,'Stats_Controller','members_increase_decrease');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (105,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (107,'Device_active_links_Controller','display_device_active_links');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (108,'Members_Controller','registration_export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (109,'Members_Controller','registration_export');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (110,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (110,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (110,'Members_Controller','vat_organization_identifier');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Members_whitelists_Controller','whitelist');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Messages_Controller','activate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Messages_Controller','auto_config');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Messages_Controller','deactivate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Messages_Controller','member');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Messages_Controller','message');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Messages_Controller','preview');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Redirect_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (111,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (112,'Connection_Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (112,'Requests_Controller','approval_template');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (112,'Requests_Controller','request');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (113,'Members_Controller','notification_settings');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (114,'Members_Controller','registration');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (115,'Sms_Controller','sms');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (116,'Address_points_Controller','address_point');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (116,'Address_points_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (116,'Address_points_Controller','town');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (117,'Log_queues_Controller','comments');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (117,'Log_queues_Controller','log_queue');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (117,'Login_logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (117,'Logs_Controller','logs');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (119,'Members_whitelists_Controller','whitelist');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (120,'Subnets_Controller','dhcp');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (120,'Subnets_Controller','dns');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (120,'Subnets_Controller','qos');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (120,'Subnets_Controller','redirect');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (120,'Subnets_Controller','subnet');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (122,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (122,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (122,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (122,'Members_Controller','vat_organization_identifier');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (123,'Address_points_Controller','street');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (123,'Address_points_Controller','town');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (125,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (125,'Members_Controller','name');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (125,'Members_Controller','organization_id');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (125,'Members_Controller','vat_organization_identifier');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (127,'Members_Controller','address');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (127,'Members_Controller','comment');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (127,'Members_Controller','members');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (127,'Members_Controller','qos_ceil');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (127,'Members_Controller','qos_rate');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (128,'Network_Controller','public_ip_nat');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (128,'Network_Controller','public_ports');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (128,'Network_Controller','smtp_exceptions');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (129,'Gpon_Controller','gpon');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (129,'Gpon_Controller','olt');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (129,'Gpon_Controller','ont');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (130,'Contracts_Controller','contract');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (131,'Contracts_Controller','contract');
INSERT INTO `axo_map` (`acl_id`, `section_value`, `value`) VALUES (132,'Contracts_Controller','contract');
/*!40000 ALTER TABLE `axo_map` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `acl`
--

LOCK TABLES `acl` WRITE;
/*!40000 ALTER TABLE `acl` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `acl` (`id`, `note`) VALUES (38,'Adminstratori mohou spravovat vsechny cleny a uzivatele, presmerovani a zalohovani.');
INSERT INTO `acl` (`id`, `note`) VALUES (40,'Řádný člen vidi svoje ucty (accounts) a transakce na nich, ale nemohou je editovat. Mohou ale tvorit nove transakce pro casti sveho kreditu na ucty jinych clenu.');
INSERT INTO `acl` (`id`, `note`) VALUES (43,'Řádný člen vidi svuj ucet');
INSERT INTO `acl` (`id`, `note`) VALUES (44,'Řádný člen vidí a upravují svoje loginy a hesla.');
INSERT INTO `acl` (`id`, `note`) VALUES (47,'Tech0 mohou editovat a pridavat vlastni zarizeni.');
INSERT INTO `acl` (`id`, `note`) VALUES (49,'Tech4 mohou editovat a pridavat vsechna zarizeni, spravovat presmerovani a zalohovani.');
INSERT INTO `acl` (`id`, `note`) VALUES (51,'Radní muze spravovat vse u clenu a uzivatelu.');
INSERT INTO `acl` (`id`, `note`) VALUES (52,'Radní vidí zarizeni, ale nema prave je editovat.');
INSERT INTO `acl` (`id`, `note`) VALUES (54,'Predseda a jednatel schvaluji prace.');
INSERT INTO `acl` (`id`, `note`) VALUES (56,'RK Rada Tech6: vidi vse, ne editovat');
INSERT INTO `acl` (`id`, `note`) VALUES (57,'Admini mohou spravovat preklady a veskere nastaveni');
INSERT INTO `acl` (`id`, `note`) VALUES (58,'Tech1 mohou prohlizet, pridavat  jen nektere polozky u clenu a uzivatelu');
INSERT INTO `acl` (`id`, `note`) VALUES (59,'Tech1 maji pravo videt a pridavat login, telefon a heslo.');
INSERT INTO `acl` (`id`, `note`) VALUES (60,'Revizni komise muze editovat pouze informace o sobe, nikoliv vsak zarizeni.');
INSERT INTO `acl` (`id`, `note`) VALUES (61,'Admini mohou posilat  e-maily z freenetisu');
INSERT INTO `acl` (`id`, `note`) VALUES (62,'Vsichni clenove sdruzeni nemohou potvrzovat sve vlastni prace.');
INSERT INTO `acl` (`id`, `note`) VALUES (63,'Radní smi potvrzovat prace.');
INSERT INTO `acl` (`id`, `note`) VALUES (64,'Řádný člen si mohou vytvaret, editovat a mazat sve prace.');
INSERT INTO `acl` (`id`, `note`) VALUES (65,'Řádný člen vidi jen sve vlastni aplikacni heslo.');
INSERT INTO `acl` (`id`, `note`) VALUES (66,'Admini mohou editovat aplikacni heslo vsem, nesmi je ale videt');
INSERT INTO `acl` (`id`, `note`) VALUES (68,'Tech1 vidí zařízení + správce+IP');
INSERT INTO `acl` (`id`, `note`) VALUES (69,'Tech4  mohou editovat adminy zařízení.');
INSERT INTO `acl` (`id`, `note`) VALUES (70,'Tech5 - vidí i login/passwd zařízení');
INSERT INTO `acl` (`id`, `note`) VALUES (71,'Tech6 can add+edit logins and passwords of devices.');
INSERT INTO `acl` (`id`, `note`) VALUES (74,'Řádný člen muze pridat vlastni kontakty');
INSERT INTO `acl` (`id`, `note`) VALUES (75,'Tech1 vidí tarify členů, nemohou je editovat.');
INSERT INTO `acl` (`id`, `note`) VALUES (76,'Tech1 view + add all comments');
INSERT INTO `acl` (`id`, `note`) VALUES (77,'Řádný člen vidí svoje povolené subnety.');
INSERT INTO `acl` (`id`, `note`) VALUES (78,'Tech10 a admini mohou spravovat cloudy.');
INSERT INTO `acl` (`id`, `note`) VALUES (79,'Administrators can administer variable symbols');
INSERT INTO `acl` (`id`, `note`) VALUES (80,'Řádný člen, čekatel a uživatel může změnit svoje heslo');
INSERT INTO `acl` (`id`, `note`) VALUES (81,'Pokladník smí vidět/přidat/upravit všechny finanční záznamy');
INSERT INTO `acl` (`id`, `note`) VALUES (82,'Všichni mohou přidat a vidět vlastní záznamy, ne komentáře');
INSERT INTO `acl` (`id`, `note`) VALUES (83,'Tech6 vidí povolené podsítě členů');
INSERT INTO `acl` (`id`, `note`) VALUES (85,'Administrators can see logs of actions.');
INSERT INTO `acl` (`id`, `note`) VALUES (86,'Administrators can see login logs.');
INSERT INTO `acl` (`id`, `note`) VALUES (87,'Users can see their login logs.');
INSERT INTO `acl` (`id`, `note`) VALUES (88,'Tech6 vidí a edituje žádosti o připojení');
INSERT INTO `acl` (`id`, `note`) VALUES (89,'Regular members and applicants can add new connection request and they can view their requests.');
INSERT INTO `acl` (`id`, `note`) VALUES (90,'Tech1 - Vidí povolené Podsítě a datové toky');
INSERT INTO `acl` (`id`, `note`) VALUES (91,'Tech1 - vidí vlastní i cizí finanční pohyby');
INSERT INTO `acl` (`id`, `note`) VALUES (92,'Tech1 - smí vidět stav členství');
INSERT INTO `acl` (`id`, `note`) VALUES (93,'Předseda+místopř. může přijímat nebo mazat žadatele o členství');
INSERT INTO `acl` (`id`, `note`) VALUES (94,'Radní smí měnit všechny záznamy');
INSERT INTO `acl` (`id`, `note`) VALUES (95,'Člen skupiny vidí všechny členy a uživatele');
INSERT INTO `acl` (`id`, `note`) VALUES (96,'Tech6 může nastavit přesměrování, posílá upozornění');
INSERT INTO `acl` (`id`, `note`) VALUES (97,'Tech6 vidí chybové logy');
INSERT INTO `acl` (`id`, `note`) VALUES (98,'Tech1 vidí kredity');
INSERT INTO `acl` (`id`, `note`) VALUES (99,'Tech6 vidí-maže-upravuje kontakty, komentáře a filtry');
INSERT INTO `acl` (`id`, `note`) VALUES (100,'Pokladník aktivuje zprávy pro dlužníky');
INSERT INTO `acl` (`id`, `note`) VALUES (101,'Radní vidí finance TEST');
INSERT INTO `acl` (`id`, `note`) VALUES (102,'Tech6 mohou přidat a editovat komentáře u členů,uživatelů a žádostí o připojení');
INSERT INTO `acl` (`id`, `note`) VALUES (103,'Radní a kontrolor vidí statistiky');
INSERT INTO `acl` (`id`, `note`) VALUES (105,'Tech4 exportuje přihlášky');
INSERT INTO `acl` (`id`, `note`) VALUES (107,'Technici mohou zobrazit aktivni odkazy zarizeni');
INSERT INTO `acl` (`id`, `note`) VALUES (108,'Regular members and applicants can export own registration');
INSERT INTO `acl` (`id`, `note`) VALUES (109,'Engineers can export all registrations');
INSERT INTO `acl` (`id`, `note`) VALUES (110,'Applicants can show own profile');
INSERT INTO `acl` (`id`, `note`) VALUES (111,'Radní upravuje přesměr a whitelist');
INSERT INTO `acl` (`id`, `note`) VALUES (112,'Engineers can manage connection requests');
INSERT INTO `acl` (`id`, `note`) VALUES (113,'Tech4+radni+pokl');
INSERT INTO `acl` (`id`, `note`) VALUES (114,'Tech8 pridava prihlasky ANO');
INSERT INTO `acl` (`id`, `note`) VALUES (115,'Právo používat SMS systém');
INSERT INTO `acl` (`id`, `note`) VALUES (116,'Tech6 upravují všechny adresní body');
INSERT INTO `acl` (`id`, `note`) VALUES (117,'Náhled do logů Tech10');
INSERT INTO `acl` (`id`, `note`) VALUES (119,'Tech6 a Tech4 vidí bílé listiny členů');
INSERT INTO `acl` (`id`, `note`) VALUES (120,'Tech6 nastavuje subnety - DHCP');
INSERT INTO `acl` (`id`, `note`) VALUES (122,'Zájemce = Aplicant can edit own info, org ID, org VAT-ID');
INSERT INTO `acl` (`id`, `note`) VALUES (123,'Všichni vidí vlastní ulice a města');
INSERT INTO `acl` (`id`, `note`) VALUES (125,'Člen vidí a přidává svoje IČ / DIČ');
INSERT INTO `acl` (`id`, `note`) VALUES (127,'Tech 6 pridat komentář k member');
INSERT INTO `acl` (`id`, `note`) VALUES (128,'nat a port');
INSERT INTO `acl` (`id`, `note`) VALUES (129,'GPON správa: System administrators a Engineers (Tech 1+).');
INSERT INTO `acl` (`id`, `note`) VALUES (130,'Správa smluv: System administrators (plné), Executive counsil + Pokladník (bez mazání). [g32]');
INSERT INTO `acl` (`id`, `note`) VALUES (131,'Správa smluv: System administrators (plné), Executive counsil + Pokladník (bez mazání). [g25]');
INSERT INTO `acl` (`id`, `note`) VALUES (132,'Správa smluv: System administrators (plné), Executive counsil + Pokladník (bez mazání). [g45]');
/*!40000 ALTER TABLE `acl` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `aro_groups`
--

LOCK TABLES `aro_groups` WRITE;
/*!40000 ALTER TABLE `aro_groups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (21,0,1,40,'All','all');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (22,21,2,37,'Regular members','regular_members');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (23,21,38,39,'Registered applicants','registered_applicants');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (24,22,4,4,'Auditing comittee','auditing_comittee');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (25,22,5,8,'Executive counsil','executive_counsil');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (26,22,9,32,'Engineers','engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (28,25,6,7,'Předseda a místopředseda','chairman_and_agent');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (29,26,10,31,'Tech 1','first_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (32,22,33,34,'System administrators','admins');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (33,22,35,35,'Users of regular members','users');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (34,29,29,30,'VoIP admins','voip_admins');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (35,29,11,28,'Second-degree certified engineers','second_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (36,35,12,27,'Third-degree certified engineers','third_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (37,36,13,26,'Tech 4 - vidí nastavení zař. a připojuje','fourth_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (38,37,14,25,'Fifth-degree certified engineers','fifth_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (39,38,15,24,'Tech6 -','sixth_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (40,39,16,23,'Seventh-degree certified engineers','seventh_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (41,40,17,22,'Tech8 certified engineers','eighth_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (42,41,18,21,'Nineth-degree certified engineers','nineth_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (43,42,19,20,'Tenth-degree certified engineers','tenth_degree_certified_engineers');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (44,22,3,36,'Owners of company telephones and SMS','telephonists');
INSERT INTO `aro_groups` (`id`, `parent_id`, `lft`, `rgt`, `name`, `value`) VALUES (45,21,40,41,'Pokladník','pokladnik');
/*!40000 ALTER TABLE `aro_groups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `aro_groups_map`
--

LOCK TABLES `aro_groups_map` WRITE;
/*!40000 ALTER TABLE `aro_groups_map` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (82,21);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (123,21);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (40,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (43,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (44,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (62,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (64,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (65,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (74,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (77,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (80,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (82,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (87,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (89,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (108,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (123,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (125,22);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (80,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (82,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (89,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (108,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (110,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (122,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (123,23);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (56,24);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (60,24);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (103,24);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (115,24);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (117,24);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (51,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (52,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (56,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (63,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (94,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (101,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (103,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (111,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (113,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (131,25);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (47,26);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (107,26);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (109,26);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (54,28);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (93,28);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (58,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (59,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (68,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (75,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (76,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (90,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (91,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (92,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (98,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (129,29);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (38,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (57,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (61,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (66,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (78,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (79,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (85,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (86,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (88,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (116,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (128,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (129,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (130,32);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (80,33);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (82,33);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (123,33);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (49,37);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (69,37);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (88,37);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (105,37);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (113,37);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (119,37);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (70,38);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (56,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (71,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (83,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (85,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (96,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (97,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (99,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (102,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (112,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (115,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (116,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (119,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (120,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (127,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (128,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (129,39);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (114,41);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (117,42);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (78,43);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (115,44);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (81,45);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (95,45);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (100,45);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (101,45);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (113,45);
INSERT INTO `aro_groups_map` (`acl_id`, `group_id`) VALUES (132,45);
/*!40000 ALTER TABLE `aro_groups_map` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `account_attributes`
--

LOCK TABLES `account_attributes` WRITE;
/*!40000 ALTER TABLE `account_attributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (12000,'Nehmotné výsledky výzkumu a vývoje',42,45,0,0,2,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (13000,'Software',42,45,0,0,3,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (14000,'Ocenitelná práva',42,45,0,0,4,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (18000,'Drobný dlouhodobý nehmotný majetek',42,45,0,0,5,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (19000,'Ostatní dlouhodobý nehmotný majetek',42,45,0,0,6,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (21000,'Stavby',42,45,0,0,12,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (22000,'Samostatné movité věci a soubory movitých věcí',42,45,0,0,13,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (25000,'Pěstitelské celky trvalých porostů',42,45,0,0,14,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (26000,'Základní stádo a tažná zvířata',42,45,0,0,15,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (28000,'Drobný dlouhodobý hmotný majetek',42,45,0,0,16,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (29000,'Ostatní dlouhodobý hmotný majetek',42,45,0,0,17,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (31000,'Pozemky',42,45,0,0,10,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (32000,'Umělecká díla, předměty a sbírky',42,45,0,0,11,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (41000,'Nedokončený dlouhodobý nehmotný majetek',42,45,0,0,7,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (42000,'Nedokončený dlouhodobý hmotný majetek',42,45,0,0,18,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (43000,'Pořizovaný dlouhodobý finanční majetek',42,45,0,0,27,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (51000,'Poskytnuté zálohy na dlouhodobý nehmotný majetek',42,45,0,0,8,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (52000,'Poskytnuté zálohy na dlouhodobý hmotný majetek',42,45,0,0,19,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (61000,'Podíly v ovládaných a řízených osobách',42,45,0,0,21,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (62000,'Podíly v osobách pod podstatným vlivem',42,45,0,0,22,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (63000,'Dluhové cenné papíry držené do splatnosti',42,45,0,0,23,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (66000,'Půjčky organizačnm složkám',42,45,0,0,24,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (67000,'Ostatní dlouhodobé půjčky',42,45,0,0,25,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (69000,'Ostatní dlouhodobý finanční majetek',42,45,0,0,26,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (72000,'Oprávky k nehmotným výsledkům výzkumu a vývoje',42,45,0,0,29,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (73000,'Oprávky k softwaru',42,45,0,0,30,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (74000,'Oprávky k ocenitelným právům',42,45,0,0,31,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (78000,'Oprávky k drobnému dlouhodobému nehmotnému majetku',42,45,0,0,32,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (79000,'Oprávky k ostatnímu dlouhodobému nehmotnému majetku',42,45,0,0,33,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (81000,'Oprávky ke stavbám',42,45,0,0,34,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (82000,'Oprávky  k samost. movitým věcem a souborům movitých věcí',42,45,0,0,35,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (85000,'Oprávky k pěstitelským celkům trvalých porostů',42,45,0,0,36,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (86000,'Oprávky k základnímu stádu a tažným zvířatům',42,45,0,0,37,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (88000,'Oprávky k drobnému dlouhodobému hmotnému majetku',42,45,0,0,38,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (89000,'Oprávky k ostatnímu dlouhodobému hmotnému majetku',42,45,0,0,39,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (111000,'Pořizovaný materiál',42,45,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (112000,'Materiál na skladě',42,45,0,0,42,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (119000,'Materiál na cestě',42,45,0,0,43,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (121000,'Nedokončená výroba',42,45,0,0,44,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (122000,'Polotovary vlastní výroby',42,45,0,0,45,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (123000,'Výrobky',42,45,0,0,46,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (124000,'Zvířata',42,45,0,0,47,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (131000,'Pořizované zboží',42,45,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (132000,'Zboží na skladě a v prodejnách',42,45,0,0,48,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (139000,'Zboží na cestě',42,45,0,0,49,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (211000,'Pokladna',42,45,0,0,72,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (213000,'Ceniny',42,45,0,0,73,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (221000,'Účty v bankách',42,45,0,0,74,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (221100,'Účet kreditu',42,45,0,0,74,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (221101,'Provozní účet',42,45,0,0,74,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (221102,'Účet infrastruktury',42,45,0,0,74,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (221103,'Projektový účet',42,45,0,0,74,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (231000,'Krátkodobé bankovní úvěry',28,45,0,0,123,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (232000,'Eskontní úvěry',28,45,0,0,124,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (241000,'Emitované krátkodobé dluhopisy',28,45,0,0,125,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (249000,'Ostatní krátkodobé finanční výpomoci',28,45,0,0,127,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (251000,'Majetkové cenné papíry k obchodování',42,45,0,0,75,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (253000,'Dluhové cenné papíry k obchodování',42,45,0,0,76,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (255000,'Vlastní dluhopisy',28,45,0,0,126,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (256000,'Ostatní cenné papíry ',42,45,0,0,77,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (259000,'Pořizovaný krátkodobý finanční majetek',42,45,0,0,78,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (261000,'Peníze na cestě',42,45,0,0,79,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (311000,'Odběratelé',42,45,0,1,52,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (312000,'Směnky k inkasu',42,45,0,0,53,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (313000,'Pohledávky za eskontované cenné papíry',42,45,0,0,54,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (314000,'Poskytnuté provozní zálohy a zálohy na zásoby',42,45,0,0,50,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (315000,'Ostatní pohledávky',42,45,0,0,56,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (321000,'Dodavatelé',28,45,0,1,106,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (322000,'Směnky k úhradě',28,45,0,0,107,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (324000,'Přijaté zálohy',28,45,0,0,108,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (325000,'Ostatní závazky',28,45,0,0,109,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (331000,'Zaměstnanci',28,45,0,0,110,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (333000,'Ostatní závazky vůči zaměstnancům',28,45,0,0,111,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (335000,'Pohledávky za zaměstnanci',42,45,0,0,57,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (336000,'Zúčtování s institucemi sociál. zabezpečení a zdravot. pojištění',28,45,0,0,58,8,112,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (336001,'Sociální pojištění',28,45,0,0,58,8,112,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (336002,'Zdrav. pojištění VZP',28,45,0,0,58,8,112,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (336003,'Zdrav. pojištění HUZP',28,45,0,0,58,8,112,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (341000,'Daň z příjmů',28,45,0,0,59,8,113,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (342000,'Ostatní přímé daně',28,45,0,0,60,8,114,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (342001,'Daň z příjmů zaměstnanců zálohová',28,45,0,0,60,8,114,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (342002,'Daň z příjmů zaměstnanců srážková',28,45,0,0,60,8,114,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (343000,'Daň z přidané hodnoty',28,45,0,0,61,8,115,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (345000,'Ostatní daně a poplatky',28,45,0,0,62,8,116,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (346000,'Nároky na dotace a ost. zúčt. se státním rozpočtem',28,45,0,0,63,8,117,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (348000,'Nároky na dotace a ost. zúčt. s rozpočtem územních celků',28,45,0,0,64,8,118,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (349000,'Vyrovnávací účet pro DPH',42,45,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (358000,'Pohledávky za účastníky sdružení',42,45,0,0,65,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (367000,'Závazky z upsaných nesplacených cenných  papírů a vkladů',28,45,0,0,119,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (368000,'Závazky k účastníkům sdružení',28,45,0,0,120,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (373000,'Pohledávky a závazky z pevných termínových operací',28,45,0,0,66,8,121,18,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (375000,'Pohledávky z emitovaných dluhopisů',42,45,0,0,67,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (378000,'Jiné pohledávky',42,45,0,0,68,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (379000,'Jiné závazky',28,45,0,0,122,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (381000,'Náklady příštích období',42,45,0,0,81,10,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (383000,'Výdaje příštích období',28,45,0,0,127,19,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (384000,'Výnosy příštích období',28,45,0,0,127,19,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (385000,'Příjmy příštích období',42,45,0,0,82,10,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (386000,'Kursové rozdíly aktivní',42,45,0,0,83,10,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (387000,'Kursové rozdíly pasivní',28,45,0,0,127,19,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (388000,'Dohadné účty aktivní',42,45,0,0,69,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (389000,'Dohadné účty pasivní',28,45,0,0,103,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (391000,'Opravná položka k pohledávkám',42,45,0,0,70,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (395000,'Vnitřní zúčtování',42,45,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (396000,'Spojovací účet při sdružení',42,45,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (501000,'Spotřeba materiálu',43,48,1,0,3,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (501001,'Spotřeba materiálu - SÍŤ',43,48,1,0,3,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (502000,'Spotřeba energie',43,48,1,0,4,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (503000,'Spotřeba ostatních neskladovatelných dodávek',43,48,1,0,5,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (504000,'Prodané zboží',43,48,1,0,6,2,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (511000,'Opravy a udržování',43,48,1,0,8,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (512000,'Cestovné',43,48,1,0,9,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (513000,'Náklady na reprezentaci',44,48,1,0,10,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (518000,'Ostatní služby',43,48,1,0,11,3,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (521000,'Mzdové náklady',43,48,1,0,13,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (521001,'Mzdové náklady - HPP',43,48,1,0,13,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (521002,'Mzdové náklady - dohody',43,48,1,0,13,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (524000,'Zákonné sociální pojištění',43,48,1,0,14,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (524001,'Sociální pojištění',43,48,1,0,14,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (524002,'Zdravotní pojištění VZP',43,48,1,0,14,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (524003,'Zdravotní pojištění HUZP',43,48,1,0,14,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (525000,'Ostatní sociální pojištění',44,48,1,0,15,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (527000,'Zákonné sociální náklady',43,48,1,0,16,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (528000,'Ostatní sociální náklady',44,48,1,0,17,4,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (531000,'Daň silniční',43,48,1,0,19,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (532000,'Daň z nemovitostí',43,48,1,0,20,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (538000,'Ostatní daně a poplatky',43,48,1,0,21,5,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (541000,'Smluvní pokuty a úroky z prodlení',43,48,1,0,23,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (542000,'Ostatní pokuty a penále',44,48,1,0,24,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (543000,'Odpis nedobytné pohledávky',44,48,1,0,25,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (544000,'Úroky',43,48,1,0,26,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (545000,'Kursové ztráty',43,48,1,0,27,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (546000,'Dary',44,48,1,0,28,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (548000,'Manka a škody',44,48,1,0,29,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (549000,'Jiné ostatní náklady',43,48,1,0,30,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (549001,'Bankovní poplatky',43,48,1,0,30,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (549002,'Jiné ostatní náklady (pojistné apod.)',43,48,1,0,30,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (549999,'Jiné ostatní náklady - přeplatky',44,48,1,0,30,6,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (551000,'Odpisy dlouhodobého nehmotného a hmotného majetku',43,48,1,0,32,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (551001,'Odpisy dlouhodobého nehmotného a hmotného majetku',43,48,1,0,32,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (551002,'Odpisy dlouhodobého nehmotného a hmotného majetku',44,48,1,0,32,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (552000,'Zůstatková cena prodaného dlouh. nehmotného a hmotného majetku',43,48,1,0,33,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (553000,'Prodané cenné papíry a podíly',43,48,1,0,34,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (554000,'Prodaný materiál',43,48,1,0,35,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (556000,'Tvorba rezerv',44,48,1,0,36,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (559000,'Tvorba opravných položek',44,48,1,0,37,7,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (581000,'Poskytnuté příspěvky zúčtované mezi organizačními složkami',43,48,1,0,39,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (582000,'Poskytnuté členské příspěvky',43,48,1,0,40,8,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (591000,'Daň z příjmů',44,48,1,0,83,127,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (595000,'Dodatečné odvody daně z příjmů',44,48,1,0,42,9,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (601000,'Tržby za vlastní výrobky',43,48,1,0,46,12,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (602001,'Tržby z prodeje služeb KULTURA',43,48,1,0,47,12,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (602002,'Tržby z prodeje služeb SÍŤ',43,48,1,0,47,12,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (604000,'Tržby za prodané zboží',43,48,1,0,48,12,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (611000,'Změna stavu zásob nedokončené výroby',43,48,1,0,50,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (612000,'Změna stavu zásob polotovarů',43,48,1,0,51,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (613000,'Změna stavu zásob výrobků',43,48,1,0,52,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (614000,'Změna stavu zvířat',43,48,1,0,53,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (621000,'Aktivace materiálu a zboží',43,48,1,0,55,14,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (622000,'Aktivace vnitroorganizačních služeb',43,48,1,0,56,14,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (623000,'Aktivace dlouhodobého nehmotného majetku',43,48,1,0,57,14,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (624000,'Aktivace dlouhodobého hmotného majetku',43,48,1,0,58,14,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (641000,'Smluvní pokuty a úroky z prodlení',43,48,1,0,60,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (642000,'Ostatní pokuty a penále',43,48,1,0,61,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (643000,'Platby za odepsané pohledávky',43,48,1,0,62,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (644000,'Úroky',43,48,1,0,63,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (645000,'Kursové zisky',43,48,1,0,64,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (648000,'Zúčtování fondů',43,48,1,0,65,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (649000,'Jiné ostatní výnosy',43,48,1,0,66,15,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (652000,'Tržby z prodeje dlouhodobého nehmotného a hmotného majetku',43,48,1,0,68,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (653000,'Tržby z prodeje cenných papírů a podílů',43,48,1,0,69,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (654000,'Tržby z prodeje materiálu',43,48,1,0,70,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (655000,'Výnosy z krátkodobého finančního majetku',43,48,1,0,71,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (656000,'Zúčtování rezerv',43,48,1,0,72,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (657000,'Výnosy z dlouhodobého finančního majetku',43,48,1,0,73,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (659000,'Zúčtování opravných položek',43,48,1,0,74,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (681000,'Přijaté příspěvky zúčtované mezi organizačními složkami',43,48,1,0,76,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (682000,'Přijaté příspěvky (dary)',43,48,1,0,77,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (684000,'Přijaté členské příspěvky',43,48,1,0,78,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (691000,'Provozní dotace',44,48,1,0,80,18,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (901000,'Vlastní jmění',28,45,0,0,87,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (911000,'Fondy',28,45,0,0,88,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (921000,'Oceňovací rozdíly z přecenění majetku a závazků',28,45,0,0,89,13,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (931000,'Výsledek hospodaření ve schvalovacím řízení',28,45,0,0,92,127,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (932000,'Nerozdělený zisk, neuhrazená ztráta minulých let',28,45,0,0,93,127,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (941000,'Rezervy',28,45,0,0,96,16,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (951000,'Dlouhodobé bankovní úvěry',28,45,0,0,98,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (953000,'Emitované dluhopisy',28,45,0,0,99,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (954000,'Závazky z pronájmu',28,45,0,0,100,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (955000,'Přijaté dlouhodobé zálohy',28,45,0,0,101,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (958000,'Dlouhodobé směnky k úhradě',28,45,0,0,102,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (959000,'Ostatní dlouhodobé závazky',28,45,0,0,104,17,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (961000,'Počáteční účet rozvažný',0,47,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (962000,'Konečný účet rozvažný',0,47,0,0,0,0,0,0,NULL);
INSERT INTO `account_attributes` (`id`, `name`, `type`, `kind`, `activity`, `track_balance`, `line`, `line_short`, `line_credits`, `line_credits_short`, `comment`) VALUES (963000,'Účet výsledku hospodaření',0,47,0,0,0,0,0,0,NULL);
/*!40000 ALTER TABLE `account_attributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `enum_types`
--

LOCK TABLES `enum_types` WRITE;
/*!40000 ALTER TABLE `enum_types` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (1,1,'Applicant',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (2,1,'Regular member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (3,1,'Honorary member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (4,1,'Sympathizing member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (5,1,'Non-member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (6,1,'Fee-free regular member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (7,2,'PC',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (8,2,'client',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (9,2,'router',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (10,2,'switch',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (11,3,'member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (12,3,'member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (13,3,'user',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (14,3,'other',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (15,1,'Former member',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (17,2,'notebook',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (18,4,'ICQ',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (19,4,'Jabber',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (20,4,'E-mail',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (21,4,'Phone',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (22,4,'Skype',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (23,4,'MSN',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (24,2,'home AP',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (25,4,'Website',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (26,2,'VoIP',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (27,5,'bank',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (28,5,'credit',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (30,5,'project',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (31,5,'operating',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (32,5,'infrastructure',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (33,5,'suppliers',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (34,5,'unidentified',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (35,6,'regular member fee',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (36,6,'entrance fee',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (37,6,'transfer fee',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (38,6,'bank transfer fee',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (39,6,'penalty',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (42,5,'debit',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (43,5,'tax',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (44,5,'non-tax',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (45,7,'balance sheet ',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (46,7,'sub-ledger',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (47,7,'closing',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (48,7,'income statement',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (49,8,'AP',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (50,8,'Client',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (51,9,'802.11a',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (52,9,'802.11b',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (53,9,'802.11g',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (54,9,'802.11n',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (55,10,'Directional',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (56,10,'Omnidirectional',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (57,10,'Sectional',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (58,11,'Horizontal',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (59,11,'Vertical',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (60,11,'Circular',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (61,12,'air',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (62,12,'cable',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (63,12,'single-mode optical fiber',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (64,12,'multi-mode optical fiber',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (65,9,'802.11b/g',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (66,2,'AP',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (67,11,'Horizontal and vertical',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (68,14,'Virus',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (69,14,'Spam',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (70,14,'Message',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (71,14,'Admin contacting',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (72,14,'Rules breaking',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (77,15,'redirected',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (78,15,'edited',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (79,15,'deleted',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (80,16,'RB mikrotik',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (81,16,'PC router',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (84,2,'Rychlostni_Spoj',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (85,2,'Ubiquiti',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (86,2,'PC router',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (87,8,'bridge_Wlan-Wlan',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (88,2,'W-E_WifimodeBridge',1);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (89,4,'IPv6',0);
INSERT INTO `enum_types` (`id`, `type_id`, `value`, `read_only`) VALUES (90,1,'Člen',0);
/*!40000 ALTER TABLE `enum_types` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (1,'Contact information','<p><strong><span style=\"font-family: mceinline;\">PVfree.net z.s.</span></strong></p>\n<p> </p>\n<p>Daliborka 3, Prostějov 796 01</p>\n<p>úřední dny pondělí až pátek 8-9hod a každou středu 15-17hod</p>\n<p> </p>\n<p><strong>Přihlášený uživatel:</strong></p>\n<p>{member_name}</p>\n<p>Uživatelské číslo: {member_id}</p>\n<p>Přihlášen z IP adresy: <strong><span style=\"font-family: mceinline;\">{ip_address}</span></strong></p>\n<p> </p>\n<p><strong>Finance </strong>- zůstatek kreditu: <strong><span style=\"font-family: mceinline;\">{balance} Kč</span></strong></p>\n<p> </p>\n<p>Platby za internet provádějte</p>\n<p>převodem nebo osobním vkladem na</p>\n<p>účet vedený ve <strong>FIO Bance</strong></p>\n<p><strong>číslo <strong>2200 47 65 63/2010 </strong></strong>s osobním</p>\n<p>variabilním symbolem <strong><span style=\"font-family: mceinline;\">{variable_symbol}</span></strong> .</p>\n<p>Osobní vklad je možno provádět na</p>\n<p>pobočce FIO Banky na ulici Kostelní 6 (u tržnice).</p>\n<p> </p>\n<p> </p>\n<p><strong>Kontaktní informace:</strong></p>\n<p><strong>Klubovna</strong> Daliborka 3, PV</p>\n<p><span style=\"font-family: mceinline;\">provoz pondělí až pátek 8-9hod a každou středu 15-17</span></p>\n<p><strong>HelpLinka</strong> tel. 588 207 234</p>\n<p><span style=\"font-family: mceinline;\">provozní doba na <a title=\"Web PVfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></span></p>\n<p><strong>Technici</strong> - <a title=\"Technická pomoc\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam zde</a></p>\n<p><span style=\"font-family: mceinline;\">provoz dle domluvy</span></p>\n<p> </p>\n<p><span style=\"font-family: mceinline;\" data-mce-mark=\"1\"><a title=\"email radě PVfree.net\" href=\"mailto:rada@pvfree.net\">rada@pvfree.net</a> - členské záležitosti, vyjímky ze Stanov,  <br /><a title=\"email správcům\" href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a> - správa sítě, připojování , pomoc s nastavením zařízení, technická podpora, <br /><a title=\"email pokladníkovi\" href=\"mailto:pokladnik@pvfree.net\">pokladnik@pvfree.net</a> - účtování příspěvků, <br /><br />Informační systém <a title=\"FreenetIS\" href=\"https://is.pvfree.net\" target=\"_blank\">https://is.pvfree.net</a>.</span></p>\n<p><span style=\"font-family: mceinline;\" data-mce-mark=\"1\"> </span></p>\n<p> </p>',NULL,NULL,1,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (2,'Page after canceling redirection','<p>Byl(a) jste systémem přesměrován(a) na tuto stránku.</p>\n<p>Provoz  bude obnoven během cca 5 minut.</p>\n<p>Vyčkejte...</p>',NULL,NULL,2,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (3,'Unknown device','<p><strong><span style=\"font-size: large;\">PVfree.net z.s.</span></strong></p>\n<p> </p>\n<p><span style=\"font-size: x-large;\"><span style=\"color: darkred;\">Pozor - jste připojen neznámým zařízením !</span></span></p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina: </strong></p>\n<p>používáte zařízení, které není evidováno v informačním systému spolku PVfree.net</p>\n<p> </p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p><strong> </strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a href=\"https://is.pvfree.net/freenetis\">https://is.pvfree.net/freenetis</a></p>\n<p> </p>\n<p>2) ve Vašem uživatelském účtu opravte chybný záznam nebo vložte nový záznam Přidat nové zařízení</p>\n<p> </p>\n<p>3) vyčkejte na reakci správců</p>\n<p> </p>\n<p> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>',NULL,NULL,3,0,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (4,'Interrupted membership message','<p>Dobrý den {member_name},<br /><br />Vaše žádost o přerušení byla schválena. </p>\n<p>Vaše uživatelské číslo: {member_id},  aktuální výše Vašeho kreditu je  <strong><span>{balance} Kč</span></strong></p>\n<p> </p>\n<p><strong>Kontaktní informace:</strong></p>\n<p><strong>HelpLinka</strong> tel. 588 207 234 </p>\n<p> </p>\n<p>S pozdravem Rada spolku  <a title=\"email radě PVfree.net\" href=\"mailto:rada@pvfree.net\">rada@pvfree.net</a> </p>',NULL,NULL,4,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (5,'Debtor message','<p> Pozor - stav Vašeho konta je nízký !</p>\n<p><strong>Příčina:  </strong>informační systém FreenetIS eviduje nedostatečnou výši konta - stav konta je v levém sloupci (oranžové číslo).   Tento stav je Vaší chybou, dostali jste email a SMS dostatečnou dobu předem (25. den předchozího měsíce).</p>\n<p><strong>Vaše reakce: </strong><strong> </strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a></p>\n<p>2) ve Vašem uživatelském účtu ověřte, že opravdu Vaše případná předchozí platba nedorazila nebo byla chybně zaúčtována <strong>ZKONTROLUJTE, ZDA PLATÍTE NA SPRÁVNÉ ČÍSLO ÚČTU A SE SPRÁVNÝM VS !!!</strong></p>\n<p>3) doplaťte chybějící částku a to převodem na účet PVfree  a nebo osobně na pokladně FIO banky <span style=\"color: #ff0000; font-size: small;\">-  č.účtu <strong>22 00 47 65 63 / 2010</strong>    variabilní symbol {variable_symbol}</span></p>\n<p> </p>\n<p style=\"text-align: center;\"><strong style=\"color: #ff0000; font-size: small; text-align: center;\"><a href=\"https://is.pvfree.net/freenetis/redirection/cancel.php?redirect_to=\">Kliknutím ověřuji, že jsem si hlášení přečetl, rozumím mu </a></strong></p>\n<p style=\"text-align: center;\"><strong>Zde kliknout na tlačítko</strong></p>\n<p align=\"center\"><a href=\"https://is.pvfree.net/freenetis/redirection/cancel.php?redirect_to=\"><img src=\"https://is.pvfree.net/tv/potvrzuji.png\" alt=\"Ano, vím, že je to jen upozornění a že bych si měl doplnit kredit\" align=\"center\" border=\"4\" /> </a></p>\n<p>  </p>\n<p><strong>UPOZORNĚNÍ</strong> - při nedodržení VOP vám bude ukončena smlouva dle VOP</p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a> </p>\n<p> </p>\n<p> </p>\n<p> </p>','<p> </p>\n<p><strong>PVfree.net z.s. : </strong>Pozor - stav Vašeho konta je nízký !</p>\n<p> </p>\n<p><strong> Příčina:</strong></p>\n<p>informační systém FreenetIS eviduje nedostatečnou výši konta pro povolení Vašeho provozu - stav konta je v levém sloupci (oranžové číslo)</p>\n<p><strong><span style=\"color: #ff0000;\" data-mce-mark=\"1\"> Tento stav je Vaší chybou, dostali jste email a SMS dostatečnou dobu předem (25. den předchozího měsíce).</span></strong></p>\n<p> </p>\n<p><strong><strong> Vaše reakce:</strong></strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a></p>\n<p>2) ve Vašem uživatelském účtu ověřte, že opravdu Vaše případná předchozí platba nedorazila nebo byla chybně zaúčtována <strong>ZKONTROLUJTE, ZDA PLATÍTE NA SPRÁVNÉ ČÍSLO ÚČTU A SE SPRÁVNÝM VS !!!</strong></p>\n<p>3) doplaťte chybějící částku a to převodem na účet PVfree  a nebo osobně na pokladně FIO banky - </p>\n<p>č.účtu <strong>22 00 47 65 63 / 2010</strong></p>\n<p><strong>variabilní symbol {variable_symbol}</strong></p>\n<p> </p>\n<p><strong>UPOZORNĚNÍ</strong> - při nedodržení VOP vám bude ukončena smlouva dle VOP</p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p> </p>\n<p>Tento email byl zaslán informačním systémem FreenetIS, neodpovídejte na něj.</p>','http://is.pvfree.net :    Pozor - stav Vaseho konta je nizky. ZKONTROLUJTE, ZDA PLATITE NA SPRAVNE CISLO UCTU A SE SPRAVNYM VS !!!',5,1,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (6,'Payment notice','<p style=\"text-align: center;\"><strong>Pozor - stav Vašeho konta bude brzy vyčerpán - měl(a) byste jej co nejdříve doplnit.</strong></p>\n<p style=\"text-align: center;\"><strong>Doporučená reakce:</strong></p>\n<p><strong> </strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a></p>\n<p>2) ve Vašem uživatelském účtu ověřte, že opravdu Vaše případná předchozí platba nedorazila nebo byla chybně zaúčtována.<span style=\"color: #ff0000;\"><strong> ZKONTROLUJTE, ZDA PLATÍTE NA SPRÁVNÉ ČÍSLO ÚČTU A SE SPRÁVNÝM VS !!!</strong></span></p>\n<p>3) doplaťte chybějící částku a to převodem na účet PVfree  a nebo osobně na pokladně banky </p>\n<p>4) klikněte na odkaz pro zrušení upozornění</p>\n<p> </p>\n<div><span style=\"color: #ff0000;\"><strong>Údaje pro platbu:</strong> </span></div>\n<p><span style=\"color: #ff0000;\">číslo účtu:  <strong>22 00 47 65 63 / 2010  Fio banka</strong></span></p>\n<p><span style=\"color: #ff0000;\">variabilní symbol:       <strong> {variable_symbol}</strong></span></p>\n<p><span style=\"color: #ff0000;\">aktuální výše kreditu:  <strong>{balance}</strong></span></p>\n<p><strong>výše platby je  : 320kč</strong></p>\n<p> </p>\n<p>Včasným doplněním konta se vyhnete možným nepříjemnostem s odpojením provozu.</p>\n<p>Nezapomínejte, že bankovní převody trvají až tři pracovní dny.</p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p>Tento email byl zaslán informačním systémem FreenetIS, neodpovídejte na něj. </p>\n<p> </p>\n<p><strong> </strong></p>\n<p> <strong><a href=\"https://is.pvfree.net/freenetis/redirection/cancel.php?redirect_to=\">Kliknutím ověřuji, že jsem si hlášení přečetl, rozumím <span style=\"color: #ff0000;\">m</span></a><span style=\"color: #ff0000;\"><span style=\"color: #ff0000;\">u.</span></span><br /></strong></p>\n<p> </p>\n<p align=\"center\"><strong>Zde kliknout na tlačítko</strong></p>\n<p align=\"center\"><a href=\"https://is.pvfree.net/freenetis/redirection/cancel.php?redirect_to=\"><img src=\"https://is.pvfree.net/tv/potvrzuji.png\" alt=\"Ano, vím, že je to jen upozornění a že bych si měl doplnit kredit\" align=\"center\" border=\"4\" /></a></p>','<p> </p>\n<p><strong><span style=\"color: darkgreen;\">PVfree.net z.s.</span></strong></p>\n<p><span style=\"color: darkgreen;\">Pozor - stav Vašeho konta bude brzy vyčerpán !</span></p>\n<p> </p>\n<p><strong> Příčina:  </strong>informační systém FreenetIS eviduje nízký stav konta pro příští platbu příspěvku </p>\n<p><strong>Vaše reakce pokud jste nedávno konto doplňoval(a):</strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a></p>\n<p>2) ve Vašem uživatelském účtu ověřte, že opravdu Vaše případná předchozí platba nedorazila nebo byla chybně zaúčtována.  <strong><span style=\"color: darkgreen;\">ZKONTROLUJTE, ZDA PLATÍTE NA SPRÁVNÉ ČÍSLO ÚČTU A SE SPRÁVNÝM VS !!!</span></strong></p>\n<p>3) doplaťte chybějící částku a to převodem na účet PVfree  a nebo osobně na pokladně banky</p>\n<p><span style=\"color: darkgreen;\" data-mce-mark=\"1\">Nezapomínejte, že bankovní převody trvají až tři dny.</span></p>\n<div><strong>Údaje pro platbu:</strong> </div>\n<p>číslo účtu:  <strong><strong><strong><strong>22 00 47 65 63 / 2010  Fio banka</strong></strong></strong></strong></p>\n<p>variabilní symbol:       <strong> {variable_symbol} </strong></p>\n<p><span>aktuální výše kreditu:  <strong>{balance}</strong></span></p>\n<p><strong>výše platby je  : 320kč</strong></p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>\n<p> </p>','http://is.pvfree.net: Pozor - stav Vaseho konta bude brzy vycerpan !  ZKONTROLUJTE, ZDA PLATITE NA SPRAVNE CISLO UCTU A SE SPRAVNYM VS !!!',6,1,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (7,'Unallowed connecting place','<p><strong><span style=\"font-size: large;\">PVfree.net z.s.</span></strong></p>\n<p> </p>\n<p><span style=\"font-size: x-large;\"><span style=\"color: darkred;\">Nepovolené přípojné místo</span></span></p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina: </strong></p>\n<p>informační systém FreenetIS eviduje několik Vašich přípojných lokalit, avšak není povoleno <span style=\"text-decoration: underline;\">současné</span> připojení ze všech</p>\n<p> </p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a></p>\n<p> </p>\n<p>2) ve Vašem uživatelském účtu vpravo nahoře použijte <span style=\"text-decoration: underline;\">tlačítko</span> pro přepnutí aktivní lokality</p>\n<p> </p>\n<p>3) vyčkejte alespoň 5 minut na provedení systémových změn a povolení provozu z jiné lokality</p>\n<p> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>',NULL,NULL,7,0,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (9,'Received payment notice',NULL,'<p> </p>\n<p><strong>DAŇOVÝ DOKLAD - č. {payment_id}</strong></p>\n<p><strong>Dodavatel:</strong><br /><em>PVfree.net, z.s.</em><br /><em>Daliborka 3009/3, </em><em>796 01 Prostějov</em><br /><em>IČ 26656787, DIČ CZ26656787<br /></em>Krajský soud v Brně L/10341<br /> <br /><strong>Odběratel - člen:</strong><br /><em>{member_name} (<em>členské číslo {member_id})</em></em><br /><em>{address_street} {address_street_number}, </em><em>{address_town}</em><br /><em>IČ {organization_identifier}, DIČ {vat_organization_identifier}</em></p>\n<p><br /><strong>Platební údaje:<br /></strong></p>\n<p>Předmět platby          : Platba za členství PVfree.net. z.s.</p>\n<p>Variabilní symbol       : {variable_symbol}</p>\n<p>Datum vystavení dokladu : {payment_date}</p>\n<p>Datum uskutečnění zdanitelného plnění : {payment_date}</p>\n<hr />\n<p>Rekapitulace DPH v Kč (rozpis):</p>\n<table style=\"height: 58px; width: 341px;\" border=\"1\" align=\"left\">\n<tbody>\n<tr>\n<td>Základ DPH</td>\n<td>{payment_amount_novat} Kč</td>\n</tr>\n<tr>\n<td>DPH 21%</td>\n<td>{payment_vat} Kč</td>\n</tr>\n<tr>\n<td>Celkem vč. DPH</td>\n<td>{payment_amount} Kč</td>\n</tr>\n</tbody>\n</table>\n<p><br /><br /></p>\n<p> </p>\n<p> </p>\n<hr />\n<p>Neplaťte, jedná se o daňový doklad vystavený na základě přijaté platby. Aktuální výše kreditu je: <strong>{balance},- Kč</strong></p>\n<p>Vystaveno automaticky v informačním systému FreenetIS spolku PVfree.net, z.s. , není potřeba na zprávu reagovat.</p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a>.</p>','Vase platba byla akceptovana systemem FreenetIS, aktualni vyse Vaseho kreditu je  {balance},- Kc . S pozdravem PVfree.net, z.s.',8,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (10,'Application for membership approved',NULL,'<p>Dobrý den {member_name},<br /><br />Vaše osobní údaje byly zapsány.</p>\n<p><strong>PVfree.net z.s.</strong></p>\n<p>Daliborka 3, Prostějov 796 01</p>\n<p>Úřední dny na klubovně jsou pondělí až pátek 8-9 hod a každou středu 15-17hod</p>\n<p> </p>\n<p>Vaše členské číslo: {member_id}</p>\n<p> </p>\n<p><strong><strong>Platba za členství je 100,-kč měsíčně</strong></strong></p>\n<p> </p>\n<p>První platbu je nutné provést do 14ti dnů od podepsání členské přihlášky.</p>\n<p><strong><strong>Další platby se provádí formou kreditu, doporučujeme aby platba proběhla k 20 -tému na následující měsíc!</strong></strong></p>\n<p>Platby provádějte převodem na účet vedený ve <strong>FIO bance</strong></p>\n<p><strong> </strong></p>\n<p><strong>Členství -  číslo 2103383824/2010</strong></p>\n<p> </p>\n<p>variabilním symbolem <strong>{variable_symbol}</strong> . </p>\n<p> </p>\n<p><strong>Kontaktní informace:</strong></p>\n<p><strong>Klubovna</strong> Daliborka 3, Prostějov</p>\n<p><strong>HelpLinka</strong> tel. 588 207 234 - provozní doba uvedena  na <a style=\"font-family: mceinline;\" title=\"Web PVfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a> . Číslo si poznamenejte pro případ problémů</p>\n<p><strong>Technici</strong> - <a title=\"Technická pomoc\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam zde</a> - provoz dle domluvy</p>\n<p> </p>\n<p><a style=\"font-family: mceinline;\" title=\"email radě PVfree.net\" href=\"mailto:rada@pvfree.net\">rada@pvfree.net</a> - členské záležitosti, vyjímky ze Stanov,</p>\n<p><a title=\"email správcům\" href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a> - správa sítě, připojování, pomoc s nastavením zařízení, technická podpora, <br /><br />Informační systém <a title=\"Informační systém FreenetIS\" href=\"http://is.pvfree.net\">http://is.pvfree.net</a></p>\n<p> </p>\n<p>S pozdravem PVfree.net, z.s.</p>',NULL,9,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (11,'Application for membership rejected',NULL,'<p>Dobrý den {member_name}, Vaše registrace (nebo žádost o členství) byla smazána či zamítnuta.</p>\n<p>Tuto zprávu jste obdržel(a) proto, že po Vaší registraci jste dále <strong>nepokračoval(a)  v procesu přijetí za řádného člena</strong>  nebo jste po připojení a zkušební době 14dní  neodevzdal(a) přihlášku do spolku.</p>\n<p><strong>Řešením je nová registrace a včasné odevzdání přihlášky.  Samotná registrace není automatickou žádostí o někým asistované připojení - kontaktujte HelpLinku...</strong></p>\n<p><em>S pozdravem Rada PVfree.net, z.s.</em></p>\n<p> </p>\n<p>Tento email je odesílán automaticky informačním systémem FreenetIS.</p>\n<p>Případné přesnější informace můžete získat na HelpLince 588 207 234</p>\n<p> </p>',NULL,10,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (12,'Notice of adding connection request',NULL,'<p>Dobrý den {member_name},<br /><br />Vaše žádost o připojení byla zaznamenána do systému FreenetIS <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a>.</p>\n<p><br />Detaily:<br /> <br /> {comment}<br /><br />O vyřízení / zamítnutí žádosti budete informován(a) emailem.</p>\n<p>S pozdravem správci sítě PVfree.net</p>',NULL,13,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (13,'Request for connection approved',NULL,'<p>Dobrý den {member_name},<br /><br />Váš požadavek na připojení zařízení byl schválen, detaily:<br /><br />{comment}<br /><br />S pozdravem Správci sítě PVfree.net</p>','Vas pozadavek na pripojeni zarizeni byl schvalen. Detaily emailem. Spravci site PVfree.net',11,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (14,'Request for connection rejected',NULL,'<p>Dobrý den {member_name},<br /><br />Váš požadavek na připojení zařízení byl zamítnut, detaily:<br /><br />{comment}<br /><br />S pozdravem Správci sítě PVfree.net</p>',NULL,12,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (23,'Host {device_name} is unreachable\')',NULL,'<p>Host {device_name} is unreachable since {state_changed_date}.</p>',NULL,14,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (24,'Host {device_name} is again reachable',NULL,'<p>Host {device_name} is again reachable since {state_changed_date}.</p>',NULL,15,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (25,'Test connection has expired','<p> </p>\n<p><strong><span style=\"font-size: large;\">PVfree.net z.s.</span></strong></p>\n<p> </p>\n<p>Pozor - Doba testování již uplynula !</p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina: </strong></p>\n<p>Doba testování všech výhod spolku byla vyčerpána.</p>\n<p> </p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p><strong> </strong></p>\n<p>1) přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net\">https://is.pvfree.net</a></p>\n<p> </p>\n<p>2) ve Vašem uživatelském účtu klikněte na odkaz Export přihlášky a tuto vytiskněte</p>\n<p> </p>\n<p>3) Přihlášku vlastnoručně podepište a doručte (osobně či poštou) na adresu uvedenou na této stránce vlevo nahoře</p>\n<p> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>',NULL,NULL,16,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (26,'Přerušení členství na žádost člena','<p><strong>PVfree.net z.s.</strong></p>\n<p> </p>\n<p>Pozor - máte přerušeno členství ! </p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina: </strong></p>\n<p>Vaše členství bylo na Vaši žádost přerušeno.</p>\n<p> </p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p>O obnovení členství můžete požádat emailem na spravci@pvfree.net nebo telefonicky na HelpLince při použití registrovaného kontaktního telefonu.</p>\n<p><strong> Pokud tedy chcete přerušit a zároveň neplatit, požádejte o přerušení členství !!</strong></p>\n<p> </p>\n<p> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>\n<p> </p>','<p>Vaše členství bylo <span style=\"text-decoration: underline;\">na Vaši žádost</span> přerušeno. O obnovení členství můžete požádat emailem na spravci@pvfree.net  nebo telefonicky při použití registrovaného kontaktního telefonu.</p>','Vase pripojeni bylo na Vasi zadost preruseno. Spravci PVfree.net',0,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (32,'Membership interrupt begins notification',NULL,'<p>Dobrý den <em>{member_name} (UID <em>{member_id})</em></em>,</p>\n<p>rada PVfree.net, z.s. Vám na dnešním zasedání přerušila <br />členství v naší organizaci od {activation_date} do  {deactivation_date}.</p>\n<p> </p>\n<p>S pozdravem</p>\n<p>PVfree.net</p>',NULL,17,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (33,'Konec přerušení členství',NULL,NULL,NULL,18,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (34,'Ukončení členství','','<p>Dobrý den <em>{member_name},</em><br />PVfree.net, z.s. ukončil Vaše členství/Vaši smlouvu UID <em>{member_id}</em> v naší organizaci a to k {leaving_date} .</p>\n<p>S pozdravem</p>\n<p>PVfree.net</p>',NULL,19,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (35,'Neúplné či nepravdivé kontaktní údaje','<p><strong>PVfree.net, z.s.</strong></p>\n<p> </p>\n<h1 style=\"text-align: center;\"><strong>Uvádíte neúplné, nefunkční nebo nepravdivé kontaktní údaje </strong></h1>\n<p style=\"text-align: center;\"> </p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina: </strong></p>\n<p><strong>Vaše kontaktní údaje  jsou neúplné nebo nepravdivé </strong></p>\n<p> </p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p>1) Kontaktujte správce na tel. čísle 588 207 234</p>\n<p> </p>\n<p><strong>Ve vlastním zájmu dodržujte jednu ze základních povinností - udržovat funkční, pravdivé a úplné kontaktní údaje.</strong></p>\n<p> </p>\n<p> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>','<p><strong>PVfree.net, z.s.</strong></p>\n<p> </p>\n<h1><strong>Uvádíte neúplné, nefunkční nebo nepravdivé kontaktní údaje </strong></h1>\n<p> </p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina:</strong></p>\n<p><strong>Vaše kontaktní údaje  jsou neúplné nebo nepravdivé </strong></p>\n<p> </p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p>1) Kontaktujte správce na tel. čísle 588 207 234</p>\n<p> </p>\n<p><strong>Ve vlastním zájmu dodržujte jednu ze základních povinností - udržovat funkční, pravdivé a úplné kontaktní údaje.</strong></p>\n<p> </p>\n<p> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam techniků zde</a></p>\n<p> </p>',NULL,0,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (42,'Zánik členství podle Stanov','','<p><span style=\"font-size: small;\">Dobrý den {member_name},</span><br /><br /><span style=\"font-size: small;\">Vaše členství zaniklo podle Stanov, článku 3 bodu 8h. Nyní nejste řádným členem.</span></p>\n<p><span style=\"font-size: small;\" data-mce-mark=\"1\"><strong>S pozdravem Rada sdružení  </strong><strong style=\"font-size: small;\">PVfree.net z.s. </strong></span></p>\n<p><span style=\"font-size: small;\" data-mce-mark=\"1\"><strong style=\"font-size: small;\"><a title=\"email radě PVfree.net\" href=\"mailto:rada@pvfree.net\">rada@pvfree.net</a> </strong></span><span style=\"font-size: small;\" data-mce-mark=\"1\">Daliborka 3, Prostějov 796 01</span></p>\n<p><span style=\"font-size: small;\"> </span></p>\n<p> </p>\n<p><strong>Finance </strong>- aktuální výše Vašeho kreditu je  <strong><span style=\"color: orange;\">{balance} Kč</span></strong></p>\n<p><strong style=\"font-size: x-small;\">HelpLinka</strong><span style=\"font-size: x-small;\"> tel. 588 207 234 - </span><span style=\"font-size: x-small;\">provozní doba uvedena  na </span><a style=\"font-family: mceinline;\" title=\"Web PVfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a><span style=\"font-size: x-small;\"> .  </span></p>\n<p> </p>\n<p> </p>\n<p> </p>\n<p>Tento email byl automaticky zaslán informačním systémem FreenetIS, neodpovídejte na něj.</p>',NULL,0,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (43,'Smazání registrace','','<p><span style=\"font-size: small;\">Dobrý den {member_name},</span><br /><br /><span style=\"font-size: small;\">Vaše registrace v systému Freenetis je dlouhodobě nevyužita a bude zrušena.</span></p>\n<p><span style=\"font-size: small;\">Pokud máte zájem o připojení tak volejte na HelpLinku 588207234 nebo piště na email <a href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a>.</span></p>\n<p><span style=\"font-size: small;\">Jestli máte již přihlášku odevzdanou nebo jste ve zkušební 14ti denní lhůtě tak registrace zůstane zachována a nemusíte na tento email nijak reagovat.</span></p>\n<p> </p>\n<p><span style=\"font-size: small;\" data-mce-mark=\"1\"><strong>S pozdravem Rada spolku  </strong><strong style=\"font-size: small;\">PVfree.net z.s. </strong></span></p>\n<p><span style=\"font-size: small;\" data-mce-mark=\"1\"><strong style=\"font-size: small;\"><a title=\"email radě PVfree.net\" href=\"mailto:rada@pvfree.net\">rada@pvfree.net</a> </strong></span><span style=\"font-size: small;\" data-mce-mark=\"1\">Daliborka 3, Prostějov 796 01</span></p>\n<p>Stanovy spolku <a style=\"font-size: x-small;\" href=\"http://wiki.pvfree.net/index.php/Stanovy_sdruzeni\">http://wiki.pvfree.net/index.php/Stanovy_sdruzeni</a></p>\n<p> </p>\n<p> </p>\n<p>Tento email byl automaticky zaslán informačním systémem FreenetIS, neodpovídejte na něj.</p>',NULL,0,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (47,'Žádost o členství schválena SMS','',NULL,'Dobry den, Vase zadost byla schvalena a jste ucastnikem PVfree.net z.s. Platby provadejte na c.u.dle emailu/webu s osobnim VS {variable_symbol}. Dekujeme',0,1,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (58,'Nefunkční heslo do zařízení','<p><strong>PVfree.net z.s.</strong></p>\n<p> </p>\n<h1><strong><strong>Vaše heslo do zařízení (antény) není uvedeno nebo je </strong>nefunkční. </strong></h1>\n<p> <strong><a href=\"https://is.pvfree.net/freenetis/redirection/cancel.php?redirect_to=\">Kliknutím ověřuji, že jsem si hlášení přečetl, rozumím mu a chci znovu aktivovat přístup do sítě PVfree.net</a></strong></p>\n<p> </p>\n<p><a href=\"https://is.pvfree.net/freenetis/redirection/cancel.php?redirect_to=\"><img src=\"https://is.pvfree.net/tv/potvrzuji.png\" alt=\"Ano, vím, že je to jen upozornění a že bych si měl doplnit kredit\" align=\"center\" border=\"3\" /></a></p>\n<p> </p>\n<p><strong><img title=\"Surprised\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-surprised.gif\" alt=\"Surprised\" border=\"0\" /> Příčina:</strong></p>\n<p><strong>Vaše heslo do zařízení není uvedeno. Prosíme o uvedení Vašeho hesla do zařízení pro příjem signálu od PVfree.net, z.s.</strong></p>\n<p><span style=\"font-size: small;\"><strong> Pokud nebude heslo dodáno bude Vaše zařízení smazáno a tím pádem budete mít nefunkční připojení !</strong></span></p>\n<p><strong><img title=\"Smile\" src=\"http://fis.pvfree.net/freenetis/media/js/tinymce/plugins/emotions/img/smiley-smile.gif\" alt=\"Smile\" border=\"0\" /> Vaše reakce:</strong></p>\n<p>1) Přihlaste se svým uživatelským jménem a heslem do informačního systému FreenetIS na <a title=\"Informační systém FreenetIS\" href=\"https://is.pvfree.net/\">https://is.pvfree.net</a> </p>\n<p> </p>\n<p>2) V nabídce na levé straně této obrazovky klikněte na odkaz \"Moje pošta\" - \"Napsat novou zprávu\"</p>\n<p> </p>\n<p>3) Do kolonky Komu napište adresu \"<strong> spravci@pvfree.net</strong> \" </p>\n<p> </p>\n<p>4) Do textu zprávy napište heslo do zařízení.   Údaje zpětně ověřujeme, proto pište údaje úplné a pravdivé !!!</p>\n<p>Zprávu pak odešlete. </p>\n<p> </p>\n<p><strong>Ve vlastním zájmu dodržujte jednu ze základních povinností - udržovat funkční a pravdivé údaje a hesla. </strong></p>\n<p><strong>V případě dalších dotazů volejte: </strong></p>\n<p><strong>Helplinku 588 207 234 nebo</strong></p>\n<p><strong>Pavel Študent 736 777 445</strong> </p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net/\">www.pvfree.net</a></p>\n<p>Technici - <a title=\"Technická pomoc - komerční služba\" href=\"http://wiki.pvfree.net/index.php/Co_delat_kdyz_nevim_co_delat\">seznam techniků zde</a></p>\n<p> </p>',NULL,NULL,0,1,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (86,'Velký dlužník','Content of page for big debtors',NULL,NULL,20,0,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (88,'Zvýšení členského příspěvku','','<p>Vážená členko, vážený člene,</p>\n<p>z níže uvedených důvodů, které byly předneseny na Schůzi členů konané 10.9.2022, byla schválena nová výše členských příspěvků.<strong><br /></strong></p>\n<p> </p>\n<p><span style=\"text-decoration: underline;\" data-mce-mark=\"1\">Důvody, které nás bohužel vedou ke změně výše členského příspěvku:</span></p>\n<ul>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span data-mce-mark=\"1\">zdražení elektřiny potřebné pro provoz našich vysílačů, serverů, routerů, apod.</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span data-mce-mark=\"1\">zdražení veškerých IT komponent</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span data-mce-mark=\"1\">zdražení lidské práce - od dřevorubce po externí spolupracovníky</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span data-mce-mark=\"1\">meziroční dvouciferná inflace</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span data-mce-mark=\"1\">udržení veškerých výhod spolku na další období (Sledováni.TV, virtualizace serverů členů, školení, kulturní akce spolku, apod.)</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>udržování kvality metropolitní sítě, upgrade technologií na síti - proběhlo zvednutí základní rychlosti na 48Mbit/s (závislé právě na použitých technologiích na páteřních spojích a AP vysílačích)</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span data-mce-mark=\"1\">další rozvoj a rozšiřování sítě - jak bezdrátových, tak optických přípojek</span></p>\n</li>\n</ul>\n<h2 class=\"stranka_nadpis\"> </h2>\n<h2 class=\"stranka_nadpis\"><strong>Od 1.ledna 2023 se členský příspěvěk mění na částku 320,- Kč.</strong></h2>\n<p><strong>Je potřeba již v prosinci změnit Vaši trvalou platbu na další období.</strong></p>\n<p> </p>\n<p>Rada spolku PVfree.net, z.s.</p>\n<p>rada@pvfree.net</p>\n<p><a href=\"http://www.pvfree.net\">www.pvfree.net</a></p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (89,'SMS navýšení členského příspěvku','',NULL,'Od 1.1.2020 byl zvysen clensky prispevek na 250kc, prosim doplnte si Vas kredit. Tato zprava Vam dosla jiz drive na email zkontrolujte si Vasi emailovou schranku.',0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (92,'Záporný stav členského účtu','<p>Máte záporný stav Vašeho účtu, prosím zkontrolujte si stav Vašeho účtu nebo nás kontaktujte. V případě neřešení této situace Vám hrozí ukončení smlouvy dle VOP. Příspěvek je 320kč.</p>\n<p>S pozdravem PVfree.net</p>','<p>Máte záporný stav Vašeho účtu, prosím zkontrolujte si stav Vašeho účtu nebo nás kontaktujte. V případě neřešení této situace Vám hrozí ukončení smlouvy dle VOP. Příspěvek je 320kč.</p>\n<p>S pozdravem PVfree.net</p>','Mate zaporny stav vaseho uctu, prosim zkontrolujte a doplnte si prispevky. PVfree',0,0,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (94,'Ukončení členství — bez platby','','<p>Dobrý den <em>{member_name} (UID <em>{member_id})</em></em>,</p>\n<p>rada PVfree.net, z.s. Vám ukončila členství/smlouvu na základě Stanov<br />čl.4 odst.13c nebo dle VOP v naší organizaci a to k {leaving_date} .</p>\n<p>(neplacení déle než 1 měsíc)</p>\n<p>S pozdravem</p>\n<p>PVfree.net</p>',NULL,21,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (95,'Bez emailu',NULL,NULL,NULL,22,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (96,'Ukončení členství — vrácení platby','','<p>Dobrý den <em>{member_name},</em><br />PVfree.net, z.s. ukončila Vaše členství/smlouvu UID <em>{member_id}</em> v naší organizaci a</p>\n<p>to k {leaving_date}</p>\n<p>Přeplatek <strong>{balance},</strong>-Kč Vám bude převeden na č.ú.<strong>{ucet}<br /></strong></p>\n<p> </p>\n<p>S pozdravem</p>\n<p>PVfree.net</p>',NULL,23,NULL,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (100,'Letní den s Freenetem 2024','','<p>Ahoj Freeneťáci,</p>\n<p>Rok se s rokem sešel a proto pořádáme 10. ročník naší Freeneťácké akce</p>\n<p>Tímto Vás zveme v <strong>sobotu 22.6.2024 od 10 hod na letiště Stichovice</strong> ( <a href=\"http://www.mapy.cz/s/7bpD\" target=\"_about:blank\">na mapě naleznete zde</a> ), kde pořádáme</p>\n<p> </p>\n<p><strong>\" LETNÍ DEN S FREENETEM \"</strong></p>\n<p><br /><br />Celá akce je zamýšlena jako spolkový, zábavný, zážitkový a sportovní den pro naše členy od 0 - 99 let. Na své si přijdou jak samotné děti, tak i dospěláci :-) ...<br /><br /></p>\n<p><strong>PROGRAM:</strong></p>\n<ul>\n<li><strong>10:00 Zahájení</strong></li>\n<li><strong>11:00 Karel Pomahač- kouzelník</strong></li>\n<li><strong>12:00 H<strong>asičský zásah - zásah hasičů Vrahovice</strong><br /></strong></li>\n<li><strong>13:00 <strong>S tancem kolem světa - taneční vystoupení malých tanečnic</strong></strong></li>\n</ul>\n<p> </p>\n<p>*změna programu vyhrazena</p>\n<p><strong> </strong></p>\n<p> <strong>Na co se můžete dále těšit:</strong></p>\n<ul>\n<li>soutěže pro děti s malou odměnou</li>\n<li>bazén s lodičkami</li>\n<li><span>skákací nafukovací hrad</span></li>\n<li>malování na obličej</li>\n<li>výtvarka - tvoření pro děti</li>\n<li>obří šipky</li>\n<li>Seqway</li>\n<li>moderovaná hudba s DJ</li>\n<li>spouta další prima zábavy :-)</li>\n</ul>\n<p><br /><br />Občerstvení pro všechny věkové skupiny zajištěno na místě, parkování v těsné blízkosti areálu letiště na označených plochách zdarma.<br />Pro děti budou při plnění soutěžních her připraveny odměny vč. občerstvení. <br /><br />Předpokládaný konec akce cca 16 hod (dle počasí a účasti).<br />Akce se pořádá i za mírně nepříznivého počasí (na místě budou připraveny kryté prostory, kde se dá přečkat i nějaký ten letní deštík). <br /><br />Moc se těšíme na Vaši účast a věříme, že si to i letos společně užijeme a bude nám přát počasí. <br /><br /><strong>Vaše Velká Freeneťácká Rodina</strong><br /><br /></p>\n<p><em>PS: Pokud máte možnost věnovat pro naše děti nějaké reklamní předměty či drobné dárečky, doneste je každou středu od 15-17 hod na klubovnu spolku (Daliborka 3) . </em></p>\n<p><br />Tímto zároveň laskavě děkujeme za bezplatně poskytnuté venkovní prostory místnímu spolku Deltaklub Stichovice (<a href=\"http://www.deltaklub.cz/\" target=\"_blank\">www.deltaklub.cz</a>).</p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (103,'Dlouhé stráně PVE','','<p>Dobrý den/Ahoj </p>\n<p>milý člene/členko, je to tady, výlet na Dlouhé stráně PVE se bude konat 25.10.2025.</p>\n<p><span data-mce-mark=\"1\">Jednalo by se o zážitkovou prohlídku přečerpávací elektrárny Dlouhé stráně. Doprava a vstupenky by byly hrazeny spolkem jako výhoda spolku.</span></p>\n<p>Pokud máte zájem je možnost se tohoto výletu zůčastnit, máme ještě volnou kapacitu v autobuse.</p>\n<p>Učastnit se může <strong>člen nebo</strong> <strong>člen +1 osoba</strong> jako doprovod. </p>\n<p>Kdo by měl zájem, prosím o nahlášení formou emailu na :  <a href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a>  následně Vás budeme kontaktovat zpět s dalšími informacemi.</p>\n<p>Akce je pro omezený počet členů s doprovodem, tzv. kdo dřív přijde , ten dřív mele ... v tomto případě jede :D</p>\n<p>Ten kdo se přihlásí na email dřív ten bude zařazen do autobusu až do naplnění kapacity autobusu.</p>\n<p>S pozdravem <br /> <br />za PVfree.net předseda Pavel Študent </p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (104,'SČ 2024','','<p dir=\"ltr\"><span>Pozvánka na schůzi členů 2024</span></p>\n<p dir=\"ltr\"><span>  </span></p>\n<p dir=\"ltr\"><span>Datum.... 7. 9. 2024 (sobota)</span></p>\n<p dir=\"ltr\"><span>Čas........ 13:00 hodin</span></p>\n<p dir=\"ltr\"><span>Místo...... myslivecká chata nad Určicemi /</span><a href=\"http://www.mapy.cz/zakladni?x=17.0658161&amp;y=49.4277128&amp;z=14&amp;l=0&amp;source=coor&amp;id=17.062089999999998%2C49.42443&amp;q=49.42443N%2C%2017.06209E\"><span>mapa</span></a><span> / GPS: 49.42443N, 17.06209E</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Rada určila jako předsedajícího schůze členů: Pavla Študenta</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Program:</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>1. Zahájení</span></p>\n<p dir=\"ltr\"><span>2. Zpráva o činnosti spolku</span></p>\n<p dir=\"ltr\"><span>3. Zpráva revizní komise a pokladníka spolku, rozpočet spolku.</span></p>\n<p dir=\"ltr\"><span>4. Změny v druhu členství dle čl. 6, odst.9, písm. (h) Stanov spolku</span></p>\n<p dir=\"ltr\"><span>- přijmutí, odejmutí statusu člena seniora</span></p>\n<p dir=\"ltr\"><span>5. Diskuze a informace o dění ve spolku, kontrola finančního úřadu. </span></p>\n<p dir=\"ltr\"><span>6. Závěr</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Po ukončení schůze členů bude následovat volná diskuze &amp; občerstvení v místě konání. Po dobu trvání schůze členů platí zákaz konzumace alkoholických nápojů.</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Občerstvení zajištěno.</span></p>\n<p><span><span> </span></span></p>\n<p dir=\"ltr\"><span>Schůze členů je nejvyšší rozhodovací orgán spolku. Využijte své právo podílet se na správě spolku!</span></p>\n<p><span> </span></p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (106,'mimořádná SČ 2025','<p dir=\"ltr\"><strong>Pozvánka na mimořádnou schůzi členů 2025</strong></p>\n<p dir=\"ltr\">  </p>\n<p dir=\"ltr\">Datum.... 19. 7. 2025 (sobota)</p>\n<p dir=\"ltr\">Čas........ 13:30 hodin</p>\n<p dir=\"ltr\">Místo...... <strong>Určice</strong> “<strong>sokolovna Určice u fotbalového hřiště</strong>” (N 49°25.78562′, E 17°4.81618′) <a href=\"https://mapy.com/cs/zakladni?source=addr&amp;id=10094651&amp;x=17.0793041&amp;y=49.4297848&amp;z=19\">mapa</a></p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">Rada určila jako předsedajícího schůze členů: Pavla Šmída</p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">Schválený program:</p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">1. Zahájení</p>\n<p dir=\"ltr\">2. Zpráva o činnosti spolku, seznámení se současnou legislativou a nutnými změnami ve fungování spolku.</p>\n<p dir=\"ltr\">3. Změna stanov spolku, upravené stanovy na stránkách <a href=\"http://www.pvfree.net\">www.pvfree.net</a>.</p>\n<p dir=\"ltr\">4. Přidání druhu členského příspěvku a jeho výše 100kč</p>\n<p dir=\"ltr\">5. Diskuze a informace o spolku. </p>\n<p dir=\"ltr\">6. Závěr</p>\n<p> </p>\n<p dir=\"ltr\">Po dobu trvání schůze členů platí zákaz konzumace alkoholických nápojů.</p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">Schůze členů je nejvyšší rozhodovací orgán spolku. Využijte své právo podílet se na správě spolku!</p>\n<p> </p>\n<p dir=\"ltr\"><strong>Pro objasnění změn, konzultaci či upřesnění Vás prosíme o osobní návštěvu klubovny spolku, kde Vám rádi zodpovíme všechny dotazy a vše potřebné vysvětlíme.</strong></p>\n<p> </p>\n<p dir=\"ltr\">Navrhované změny Stanov spolku</p>\n<p> </p>\n<p dir=\"ltr\">Úplné znění Stanov k nahlédnutí <strong><a title=\"Stanovy 2025\" href=\"https://drive.google.com/file/d/1ApJfqwy38vXQmRfQ7xf9T0OzW9Hwg2Ae/view?usp=sharing\" target=\"_blank\">ZDE</a></strong></p>\n<p dir=\"ltr\">Úplné znění Finančního řádu k nahlédnutí<strong> <a title=\"Finanční řád 2025\" href=\"https://drive.google.com/file/d/17uBpSt9nzYHPMNSDXx7CjwZGDbK7CHZQ/view?usp=sharing\" target=\"_blank\">ZDE</a></strong></p>','<p dir=\"ltr\"><strong>Pozvánka na mimořádnou schůzi členů 2025</strong></p>\n<p dir=\"ltr\">  </p>\n<p dir=\"ltr\">Datum.... 19. 7. 2025 (sobota)</p>\n<p dir=\"ltr\">Čas........ 13:30 hodin</p>\n<p dir=\"ltr\">Místo...... <strong>Určice</strong> “<strong>sokolovna Určice u fotbalového hřiště</strong>” (N 49°25.78562′, E 17°4.81618′) <a href=\"https://mapy.com/cs/zakladni?source=addr&amp;id=10094651&amp;x=17.0793041&amp;y=49.4297848&amp;z=19\">mapa</a></p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">Rada určila jako předsedajícího schůze členů: Pavla Šmída</p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">Schválený program:</p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">1. Zahájení</p>\n<p dir=\"ltr\">2. Zpráva o činnosti spolku, seznámení se současnou legislativou a nutnými změnami ve fungování spolku.</p>\n<p dir=\"ltr\">3. Změna stanov spolku, upravené stanovy na stránkách <a href=\"http://www.pvfree.net\">www.pvfree.net</a>.</p>\n<p dir=\"ltr\">4. Přidání druhu členského příspěvku a jeho výše 100kč</p>\n<p dir=\"ltr\">5. Diskuze a informace o spolku. </p>\n<p dir=\"ltr\">6. Závěr</p>\n<p> </p>\n<p dir=\"ltr\">Po dobu trvání schůze členů platí zákaz konzumace alkoholických nápojů.</p>\n<p dir=\"ltr\"> </p>\n<p dir=\"ltr\">Schůze členů je nejvyšší rozhodovací orgán spolku. Využijte své právo podílet se na správě spolku!</p>\n<p> </p>\n<p dir=\"ltr\"><strong>Pro objasnění změn, konzultaci či upřesnění Vás prosíme o osobní návštěvu klubovny spolku, kde Vám rádi zodpovíme všechny dotazy a vše potřebné vysvětlíme.</strong></p>\n<p> </p>\n<p dir=\"ltr\">Navrhované změny Stanov spolku</p>\n<p> </p>\n<p dir=\"ltr\">Úplné znění Stanov k nahlédnutí <strong><a title=\"Stanovy 2025\" href=\"https://drive.google.com/file/d/1ApJfqwy38vXQmRfQ7xf9T0OzW9Hwg2Ae/view?usp=sharing\" target=\"_blank\">ZDE</a></strong></p>\n<p dir=\"ltr\">Úplné znění Finančního řádu k nahlédnutí<strong> <a title=\"Finanční řád 2025\" href=\"https://drive.google.com/file/d/17uBpSt9nzYHPMNSDXx7CjwZGDbK7CHZQ/view?usp=sharing\" target=\"_blank\">ZDE</a></strong></p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (107,'informační mail 2025','','<p dir=\"ltr\"><span>Vážení členové,</span></p>\n<p dir=\"ltr\"><span>jak již možná tušíte z předchozích členských schůzí, náš spolek v posledních letech čelí rostoucímu tlaku ze strany státních institucí. Přestože se stále aktivně bráníme, je zřejmé, že doba pokročila a model neziskového spolkového poskytování přístupu k internetu již není v dnešní společnosti dále udržitelný.</span></p>\n<p dir=\"ltr\"><span>Po konzultacích s právníky, daňovými poradci, zástupci státních institucí a ve spolupráci s dalšími obdobně zaměřenými spolky po celé České republice jsme dospěli k závěru, že jediným bezpečným a dlouhodobě udržitelným řešením je poskytování přístupu k internetu na základě zákaznického vztahu.</span></p>\n<p dir=\"ltr\"><span>Spolek se proto bude snažit prosadit změnu stanov, která rozšíří předmět činnosti o možnost výkonu vedlejší hospodářské činnosti. V rámci této činnosti bude spolek oprávněn poskytovat služby elektronických komunikací, konkrétně službu přístupu k internetu. Na základě této změny budou moci členové spolku uzavírat smlouvy o poskytování připojení k internetu.</span></p>\n<p><span><span> </span></span></p>\n<p dir=\"ltr\"><span>Možnosti, které budou pokud se změna stanov povede :</span></p>\n<ul>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><strong>Zákazník bez členství:</strong><span> Pokud budete mít zájem využívat pouze službu připojení k internetu, pro Vás se po administrativních změnách prakticky nic nemění – budete platit měsíční poplatek </span><span>320 Kč včetně DPH</span><span> a stanete se zákazníkem PVfree.net, z. s.</span><span><br /><br /></span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><strong>Zákazník a člen spolku:</strong><span> Pokud se rozhodnete zůstat členem spolku i nadále, budete po administrativních změnách platit měsíčně </span><span>320 Kč včetně DPH za připojení k internetu</span><span> a </span><span>100 Kč včetně DPH jako členský příspěvek</span><span>, tedy celkem </span><span>420 Kč měsíčně</span><span>. Zůstanete členem PVfree.net, z. s., a budete moci i nadále čerpat výhody spojené s členstvím.</span></p>\n</li>\n</ul>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (108,'info k VHČ','','<p dir=\"ltr\"><strong>Vážení členové,</strong></p>\n<p dir=\"ltr\"><span>Toto je informace pro členy, další postup a informace přijdou v následujícím období do konce roku. Nyní není třeba nic dělat.</span></p>\n<p dir=\"ltr\"><span>Členové na schůzi členů změnili stanovy. Spolek bude oprávněn poskytovat služby elektronických komunikací </span><span>“internet”</span><span>. Na základě této změny bude možné uzavírat smlouvy o poskytování připojení k internetu.</span></p>\n<p dir=\"ltr\"><span>Veškeré změny budou v platnosti od 1.1.2026</span></p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p> </p>\n<p dir=\"ltr\"><strong>1. Zákazník bez členství</strong><span><br /></span><span> Pokud budete chtít využívat jen připojení k internetu, po administrativních změnách se pro vás v zásadě nic nezmění.</span></p>\n<ul>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>320 Kč včetně DPH</span><span> — za připojení k internetu</span><span><br /><br /></span></p>\n</li>\n</ul>\n<p dir=\"ltr\"><strong>Celkem tedy 320 Kč měsíčně.</strong></p>\n<p dir=\"ltr\"><span>Zůstanete „jen“ zákazníkem PVfree.net, z. s. a budete užívat internet.</span></p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p> </p>\n<p dir=\"ltr\"><strong>2. Zákazník a zároveň člen spolku</strong><span><br /></span><span> Pokud se rozhodnete zůstat členem spolku a zároveň mít připojení k internetu, po administrativních změnách budete platit:</span></p>\n<ul>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>320 Kč včetně DPH</span><span> — za připojení k internetu</span><span><br /><br /></span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>100 Kč včetně DPH</span><span> — jako členský příspěvek</span><span><br /><br /></span></p>\n</li>\n</ul>\n<p dir=\"ltr\"><strong>Celkem tedy 420 Kč měsíčně.</strong></p>\n<p dir=\"ltr\"><span>Díky členství budete moct i nadále využívat všechny výhody, které spolek nabízí.</span></p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p><strong> </strong></p>\n<p dir=\"ltr\"><strong>3. Pouze člen spolku (bez internetu)</strong><span><br /></span><span> Pokud budete chtít být jen členem spolku a internet nevyužívat, po administrativních změnách budete platit:</span></p>\n<ul>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>100 Kč včetně DPH</span><span> — jako členský příspěvek</span><span><br /><br /></span></p>\n</li>\n</ul>\n<p dir=\"ltr\"><strong>Celkem tedy 100 Kč měsíčně.</strong></p>\n<p dir=\"ltr\"><span>Budete členem PVfree.net, z. s., a budete moct dál čerpat výhody spojené s členstvím.</span></p>\n<hr />\n<p dir=\"ltr\"><strong>Členové mohou využívat výhody členství, například:</strong><span><br /><br /></span></p>\n<ul>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>společné akce (výlety, letní den, schůze členů apod.)</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>výstavba, oprava a správa sítě</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>sledovaniTV</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>možnost zapojení do rozhodování o rozvoji a směrování sítě (hlasovací právo na členských schůzích)</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>přístup k technickým školením a workshopům na klubovně spolku (např. nastavení sítí, kyberbezpečnost, domácí IT), konzultace pro členy zdarma</span></p>\n</li>\n<li dir=\"ltr\">\n<p dir=\"ltr\"><span>možnost využití klubovny nebo jiných společných prostor</span></p>\n</li>\n</ul>\n<p>  </p>\n<hr />\n<p> </p>\n<p dir=\"ltr\"><span>Pokud budete mít jakékoliv dotazy, zkuste nejdříve nahlédnout níže. V případě potřeby nás neváhejte kontaktovat na Helplince: 588 207 234, navštívit na klubovně spolku nebo emailem na spravci@pvfree.net. Jsme tu pro vás, abychom pomohli.</span></p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p> </p>\n<p dir=\"ltr\"><strong>Týká se převod i mě?</strong><span><br /></span><span> S největší pravděpodobností ano. Podpis smlouvy se týká všech členů, kteří chtějí nadále využívat přístup na internet. Internet formou členství už nebude nadále možný. Zůstat členem samozřejmě můžete, ale budete muset platit jak členské příspěvky, tak i cenu internetových služeb.</span></p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p> </p>\n<p dir=\"ltr\"><strong>Bude pro mě změna něco znamenat?</strong><span><br /></span><span> K horšímu se nic nezmění. Vše zůstane stejné. Služby elektronických komunikací dokonce přinášejí určité výhody navíc, jako jsou zákonné možnosti reklamací a možnost využít faktury za internet v účetnictví.</span></p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p> </p>\n<p><span id=\"docs-internal-guid-b32662c5-7fff-530e-510e-23593e6e00b8\"><strong>Mění se nějak platební informace?</strong><span><br /></span><span> Platit se bude stejně. Ostatní údaje (částka, variabilní symbol) zůstávají stejné. Počítáme s tím, že změna bude nějakou dobu probíhat, a vaše předplacené členství bude vráceno na bankovní účet nebo převedeno na platbu internetového připojení podle nové smlouvy.</span></span></p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (109,'Schůze členů 2025','','<p dir=\"ltr\"><span>Pozvánka na schůzi členů 2025</span></p>\n<p dir=\"ltr\"><span>  </span></p>\n<p dir=\"ltr\"><span>Datum.... 13. 9. 2025 (sobota)</span></p>\n<p dir=\"ltr\"><span>Čas........ 13:00 hodin</span></p>\n<p dir=\"ltr\"><span>Místo...... myslivecká chata nad Určicemi /</span><a href=\"http://www.mapy.cz/zakladni?x=17.0658161&amp;y=49.4277128&amp;z=14&amp;l=0&amp;source=coor&amp;id=17.062089999999998%2C49.42443&amp;q=49.42443N%2C%2017.06209E\"><span>mapa</span></a><span> / GPS: 49.42443N, 17.06209E</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Rada určila jako předsedajícího schůze členů: Pavla Šmída</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Program:</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>1. Zahájení</span></p>\n<p dir=\"ltr\"><span>2. Zpráva o činnosti spolku</span></p>\n<p dir=\"ltr\"><span>3. Zpráva revizní komise a pokladníka spolku, rozpočet spolku.</span></p>\n<p dir=\"ltr\"><span>4. Schválení účetní uzávěrky.</span></p>\n<p dir=\"ltr\"><span>5. Změny v druhu členství dle čl. 6, odst.9, písm. (h) Stanov spolku</span></p>\n<p dir=\"ltr\"><span>- přijmutí, odejmutí statusu člena seniora</span></p>\n<p dir=\"ltr\"><span>6. Diskuze a informace o dění ve spolku. </span></p>\n<p dir=\"ltr\"><span>7. Závěr</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Po ukončení schůze členů bude následovat volná diskuze &amp; občerstvení v místě konání. Po dobu trvání schůze členů platí zákaz konzumace alkoholických nápojů.</span></p>\n<p dir=\"ltr\"><span> </span></p>\n<p dir=\"ltr\"><span>Občerstvení zajištěno.</span></p>\n<p><span><span> </span></span></p>\n<p dir=\"ltr\"><span>Schůze členů je nejvyšší rozhodovací orgán spolku. Využijte své právo podílet se na správě spolku!</span></p>\n<p><span> </span></p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (111,'info2','','<p dir=\"ltr\"><strong>Vážení členové,</strong></p>\n<p> </p>\n<p dir=\"ltr\"><strong>Od prosince bude nutné podepsat smlouvu o poskytování elektronických komunikací („Internet“), která nabude platnosti od 1. 1. 2026, dle požadavků úřadů ČR.</strong></p>\n<p> </p>\n<p dir=\"ltr\">Všem členům bude zaslán během prosince e-mail s odkazem na podpis smlouvy a další potřebné dokumenty.</p>\n<p dir=\"ltr\"><br /><strong>Zkontrolujte prosím své údaje.</strong> Podpis smlouvy je realizován pomocí SMS kódu – zabere to zhruba minutu. Po zpracování Vám na e-mail pošleme kompletní smluvní dokumentaci podepsanou i z naší strany.</p>\n<p> </p>\n<p dir=\"ltr\"><span style=\"text-decoration: underline;\"><strong>V případě dotazů nebo potřeby úpravy vašich údajů volejte Helplinku: 588 207 234</strong></span></p>\n<p> </p>\n<p dir=\"ltr\"><strong>Platba za “internet”  číslo účtu, cena 320,- a VS symbol zůstává stejné jako doposud platba za členství, tzn. nemusíte nic měnit. </strong></p>\n<p> </p>\n<p dir=\"ltr\">Členem můžete samozřejmě zůstat i nadále, je však potřeba počítat s povinností hradit členský příspěvek.</p>\n<p dir=\"ltr\">Platba za členství bude na nové číslo účtu:  2803036815 / 2010 cena 100,-  VS symbol zůstává stejný.</p>\n<p> </p>\n<p dir=\"ltr\">Informace a dokumenty jsou na našich stránkách <a href=\"http://www.pvfree.net\">www.pvfree.net</a> sekce internet</p>\n<p dir=\"ltr\"> </p>\n<hr />\n<p><strong>1. Zákazník bez členství</strong><br />320 Kč včetně DPH — za připojení k internetu<br />Zůstanete „jen“ zákazníkem PVfree.net, z. s. a budete užívat internet.</p>\n<p dir=\"ltr\"><strong>2. Zákazník a zároveň člen spolku</strong><br />320 Kč včetně DPH — za připojení k internetu<br />100 Kč včetně DPH — jako členský příspěvek<br />Celkem tedy 420 Kč včetně DPH měsíčně.</p>\n<p><strong>3. Pouze člen spolku (bez internetu)</strong><br />100 Kč včetně DPH — jako členský příspěvek</p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (112,'Přístup k internetu dočasně pozastaven','<p><strong><span style=\"font-size: large;\">Přístup k internetu dočasně pozastaven</span></strong></p>\n<p> </p>\n<p>K 1. 1. 2026 je přístup k internetu ze spolkové sítě umožněn pouze členům s nově uzavřenou smlouvou o poskytování služeb elektronických komunikací. </p>\n<p> </p>\n<p>Podle našich záznamů zatím nemáme Vaši smlouvu podepsanou, proto je připojení do internetu momentálně vypnuto. </p>\n<p> </p>\n<p><strong>Co teď udělat: </strong></p>\n<p> </p>\n<ol start=\"1\">\n<li>Napište na <a href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a> nebo volejte <strong>588 207 234</strong> – ověříme stav a pošleme vám nový odkaz k podpisu.</li>\n<li>Zkontrolujte si prosím kontaktní údaje v členské databázi (e-mail a telefon). Pokud jsou neplatné, upozornění vám nemuselo dorazit. Po aktualizaci vám odkaz obratem zašleme e-mailem. </li>\n</ol>\n<p> </p>\n<p><strong>PVfree.net, z. s.</strong></p>','<p><span style=\"font-size: large;\"><strong>Přístup k internetu dočasně pozastaven</strong></span></p>\n<p> </p>\n<p>K 1. 1. 2026 je přístup k internetu ze spolkové sítě umožněn pouze členům s nově uzavřenou smlouvou o poskytování služeb elektronických komunikací. </p>\n<p> </p>\n<p>Podle našich záznamů zatím nemáme Vaši smlouvu podepsanou, proto je připojení do internetu momentálně vypnuto. </p>\n<p> </p>\n<p><strong>Co teď udělat: </strong></p>\n<p> </p>\n<ol start=\"1\">\n<li>Napište na <a href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a> nebo volejte <strong>588 207 234</strong> – ověříme stav a pošleme vám nový odkaz k podpisu.</li>\n<li>Zkontrolujte si prosím kontaktní údaje v členské databázi (e-mail a telefon). Pokud jsou neplatné, upozornění vám nemuselo dorazit. Po aktualizaci vám odkaz obratem zašleme e-mailem. </li>\n</ol>\n<p> </p>\n<p><strong>PVfree.net, z. s.</strong></p>',NULL,0,0,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (113,'Zpráva pro členy 2026','','<p>Dobrý den {member_name},</p>\n<p><br /><strong>Platba za členství ve spolku PVfree.net, z.s. je <span style=\"text-decoration: underline;\">100,-kč měsíčně</span><br /></strong></p>\n<p><strong>Doporučujeme platbu na celý rok 2026<br /></strong></p>\n<p> </p>\n<p><strong><strong>Platby se provádí formou kreditu, doporučujeme aby platba proběhla k 20 -tému na následující měsíc!</strong></strong></p>\n<p>Platby provádějte převodem na</p>\n<p>účet vedený ve <strong>FIO bance </strong><strong>číslo <span data-mce-mark=\"1\">2103383824 / 2010</span> </strong></p>\n<p>s osobním variabilním symbolem <strong>{variable_symbol}</strong> . </p>\n<p> </p>\n<p><strong>Pokud nechcete být členem, čerpat členské výhody a platit 100kč/měsíc je nutné ukončit členství!! </strong></p>\n<p><strong>https://www.pvfree.net/cz/p/ukonceni-clenstvi/</strong></p>\n<p> </p>\n<p><strong>Kontaktní informace:</strong></p>\n<p><strong>Klubovna</strong> Daliborka 3, Prostějov</p>\n<p><strong>HelpLinka</strong> tel. 588 207 234 - provozní doba uvedena  na <a title=\"Web PVfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a> . Číslo si poznamenejte pro případ problémů</p>\n<p><strong>Technici</strong> - <a title=\"Technická pomoc\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam zde</a> - provoz dle domluvy</p>\n<p> <a title=\"email radě PVfree.net\" href=\"mailto:rada@pvfree.net\">rada@pvfree.net</a> - členské záležitosti, vyjímky ze Stanov,</p>\n<p><a title=\"email správcům\" href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a> - správa sítě, připojování, pomoc s nastavením zařízení, technická podpora,<br /><a title=\"email pokladníkovi\" href=\"mailto:pokladnik@pvfree.net\">pokladnik@pvfree.net</a> - účtování příspěvků ,</p>\n<p>S pozdravem PVfree.net, z.s.</p>',NULL,0,0,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (114,'Zpráva pro dlužníky členové','','<p><strong>PVfree.net z.s. </strong></p>\n<p>Pozor - stav Vašeho účtu je nízký !</p>\n<p> </p>\n<p><strong>Příčina:</strong></p>\n<p>informační systém FreenetIS eviduje nedostatečnou výši příspěvku pro platbu členského příspěvku</p>\n<p><strong>Tento stav je Vaší chybou, dostali jste email dostatečnou dobu předem (25. den předchozího měsíce).</strong></p>\n<p> </p>\n<p><strong><strong>Vaše reakce:</strong></strong></p>\n<p>1) do emailu 19.1.2026 Vám přišly údaje k platbě. Ověřte zda Vaše platba příspěvku nedorazila, nebo byla chybně zaúčtována <strong>ZKONTROLUJTE, ZDA PLATÍTE NA SPRÁVNÉ ČÍSLO ÚČTU A SE SPRÁVNÝM VS !!!</strong></p>\n<p>2) doplaťte chybějící částku příspěvku a to převodem na účet PVfree  a nebo osobně na pokladně FIO banky</p>\n<div> </div>\n<div><span>Pokud nebudete platit členské příspěvky, bude Vám členství ukončeno na základě stanov spolku.</span></div>\n<div> </div>\n<div> </div>\n<div><strong>Údaje pro platbu:</strong> </div>\n<p>číslo účtu:  <strong>2103383824 </strong><strong><strong>/ 2010  Fio banka</strong></strong></p>\n<p>variabilní symbol:       <strong> {variable_symbol}</strong></p>\n<p>aktuální výše kreditu:  <strong>{balance}</strong></p>\n<p><strong>výše platby je  : 100kč</strong></p>\n<p>  </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Tento email byl zaslán informačním systémem FreenetIS, neodpovídejte na něj.</p>','http://is.pvfree.net : Pozor - stav Vaseho kreditu je nizky. ZKONTROLUJTE, ZDA PLATITE NA SPRAVNE CISLO UCTU A SE SPRAVNYM VS !!!',25,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (115,'Upozornění na placení člen','','<p><strong><span>PVfree.net z.s.</span></strong></p>\n<p><span>Pozor - stav Vašeho příspěvku bude brzy vyčerpán !</span></p>\n<p> </p>\n<p><strong>Příčina:  </strong></p>\n<p>informační systém FreenetIS eviduje nízkou výši finančního kreditu pro příští platbu členského příspěvku </p>\n<p> </p>\n<p><strong>Vaše reakce:</strong></p>\n<p>1) do emailu 19.1.2026 Vám přišly údaje k platbě. Ověřte zda Vaše platba příspěvku nedorazila, nebo byla chybně zaúčtována <strong>ZKONTROLUJTE, ZDA PLATÍTE NA SPRÁVNÉ ČÍSLO ÚČTU A SE SPRÁVNÝM VS !!!</strong></p>\n<p>2) doplaťte chybějící částku příspěvku, a to převodem na účet PVfree nebo osobně na pokladně FIO banky</p>\n<p> </p>\n<p>Pokud nebudete platit členské příspěvky, bude Vám členství ukončeno na základě stanov spolku.</p>\n<p><span data-mce-mark=\"1\">Nezapomínejte, že bankovní převody trvají až tři dny.</span></p>\n<div> </div>\n<div><strong>Údaje pro platbu:</strong> </div>\n<p>číslo účtu:  <strong>2103383824 </strong><strong><strong>/ 2010  Fio banka</strong></strong></p>\n<p>variabilní symbol:       <strong> {variable_symbol}</strong></p>\n<p>aktuální výše kreditu:  <strong>{balance}</strong></p>\n<p><strong>výše platby je  : 100kč</strong></p>\n<p> </p>\n<p>Telefonická HelpLinka: 588 207 234 - provozní doba je uvedena na <a title=\"www.pvfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a></p>\n<p>Tento email byl zaslán informačním systémem FreenetIS, neodpovídejte na něj.</p>','http://is.pvfree.net: Pozor - stav Vaseho kreditu bude brzy vycerpan !  ZKONTROLUJTE, ZDA PLATITE NA SPRAVNE CISLO UCTU A SE SPRAVNYM VS !!!',26,NULL,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (117,'Žádost schválena','','<p>Dobrý den {member_name},<br /><br />Vaše osobní údaje byly zapsány.</p>\n<p><strong>PVfree.net z.s.</strong></p>\n<p>Daliborka 3, Prostějov 796 01</p>\n<p>Úřední dny na klubovně jsou pondělí až pátek 8-9 hod a každou středu 15-17hod</p>\n<p> </p>\n<p>Vaše účastnické číslo: {member_id}</p>\n<p> </p>\n<p><strong>Platba za internet je 320,-kč měsíčně </strong></p>\n<p> </p>\n<p>První platbu je nutné provést do 14ti dnů od podepsání smlouvy.</p>\n<p><strong><strong>Další platby se provádí formou kreditu, doporučujeme aby platba proběhla k 20 -tému na následující měsíc!</strong></strong></p>\n<p>Platby provádějte převodem na účet vedený ve <strong>FIO bance</strong></p>\n<p><strong>Internet -  </strong><strong>číslo 2200476563/2010</strong></p>\n<p> </p>\n<p>variabilním symbolem <strong>{variable_symbol}</strong> . </p>\n<p> </p>\n<p><strong>Kontaktní informace:</strong></p>\n<p><strong>Klubovna</strong> Daliborka 3, Prostějov</p>\n<p><strong>HelpLinka</strong> tel. 588 207 234 - provozní doba uvedena  na <a style=\"font-family: mceinline;\" title=\"Web PVfree.net\" href=\"http://www.pvfree.net\">www.pvfree.net</a> . Číslo si poznamenejte pro případ problémů</p>\n<p><strong>Technici</strong> - <a title=\"Technická pomoc\" href=\"http://www.pvfree.net/cz/m/technicka-pomoc/\">seznam zde</a> - provoz dle domluvy</p>\n<p> </p>\n<p><a title=\"email správcům\" href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a> - správa sítě, připojování, pomoc s nastavením zařízení, technická podpora,</p>\n<p><br />Informační systém <a title=\"Informační systém FreenetIS\" href=\"http://is.pvfree.net\">http://is.pvfree.net</a></p>\n<p> </p>\n<p>S pozdravem PVfree.net, z.s.</p>',NULL,27,0,0);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (118,'Doplnění OKU dle zákona č. 127/2005 Sb., o elektronických komunikacích','','<p class=\"isSelectedEnd\">Vážený zákazníku,</p>\n<p class=\"isSelectedEnd\">při kontrole smluvní dokumentace jsme zjistili, že ve Vaší smlouvě o poskytování internetových služeb nebyl uveden OKU kód.</p>\n<p class=\"isSelectedEnd\">Tento údaj je důležitý zejména v případě přechodu k jinému poskytovateli internetu.</p>\n<p class=\"isSelectedEnd\">Váš OKU kód je: <strong>{variable_symbol}</strong></p>\n<p class=\"isSelectedEnd\">OKU kód je zároveň totožný s Vaším variabilním symbolem, který používáte při platbách.</p>\n<p class=\"isSelectedEnd\">Tímto oznámením dochází k doplnění informativního údaje ke smlouvě. Ostatní ustanovení smlouvy zůstávají beze změny.</p>\n<p class=\"isSelectedEnd\">Omlouváme se za administrativní nedopatření a děkujeme za pochopení.<br />V případě dotazů jsme Vám plně k dispozici.</p>\n<p>S přáním hezkého dne</p>\n<p>PVfree.net, z.s.</p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (120,'Pivovar Hanušovice','','<p>Dobrý den/Ahoj</p>\n<p>milý člene/členko, je to tady, výlet do pivovaru Hanušovice - Holba se bude konat 30.05.2026.</p>\n<p>Jednalo by se o zážitkovou prohlídku <span>pivovaru Holba Hanušovice</span> . Doprava a vstupenky by byly hrazeny spolkem jako výhoda spolku.</p>\n<p>Pokud máte zájem je možnost se tohoto výletu zůčastnit, máme ještě volnou kapacitu v autobuse.</p>\n<p>Učastnit se může <strong>člen nebo</strong> <strong>člen +1 osoba</strong> jako doprovod. </p>\n<p>Kdo by měl zájem, prosím o nahlášení formou emailu na :  <a href=\"mailto:spravci@pvfree.net\">spravci@pvfree.net</a>  následně Vás budeme kontaktovat zpět s dalšími informacemi.</p>\n<p>Akce je pro omezený počet členů s doprovodem, tzv. kdo dřív přijde , ten dřív mele ... v tomto případě jede :D</p>\n<p>Ten kdo se přihlásí na email dřív ten bude zařazen do autobusu až do naplnění kapacity autobusu.</p>\n<p>S pozdravem<br /><br />za PVfree.net předseda Pavel Študent</p>',NULL,0,1,1);
INSERT INTO `messages` (`id`, `name`, `text`, `email_text`, `sms_text`, `type`, `self_cancel`, `ignore_whitelist`) VALUES (121,'Kontaktujte Helplinku PVfree','<p>Dobrý den,</p>\n<p>prosíme o kontaktování Helplinky PVfree, z.s.<strong> 588 207 234</strong></p>\n<p>Vaše zařízení je zavirované, nefukční nebo jinak škodí Naší síti.</p>\n<p>Děkujeme</p>\n<p>S pozdravem PVfree.net, z.s.</p>','<p>Dobrý den,</p>\n<p>prosíme o kontaktování Helplinky PVfree, z.s.<strong> 588 207 234</strong></p>\n<p>Vaše zařízení je zavirované, nefukční nebo jinak škodí Naší síti.</p>\n<p>Děkujeme</p>\n<p>S pozdravem PVfree.net, z.s.</p>',NULL,0,0,1);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-01 17:30:50
